/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#0A0A0A',
        surface: '#1A1A1A',
        border: '#2A2A2A',
        neon: {
          green: '#00FF00',
          red: '#FF0000',
          blue: '#00F3FF',
          purple: '#B537F2'
        }
      },
      fontFamily: {
        sans: ['"SF Pro Display"', '"Inter"', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
