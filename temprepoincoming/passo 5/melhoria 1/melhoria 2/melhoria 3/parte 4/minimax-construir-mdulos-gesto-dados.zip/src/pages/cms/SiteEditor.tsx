import React, { useState } from 'react';
import { Save, Eye, Upload, Image, FileText, Link2, Globe, Check, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { DeployButton } from '@/components/common/DeployButton';

interface SiteSection {
  id: string;
  name: string;
  content: string;
  type: 'text' | 'image' | 'link';
}

interface UploadedImage {
  id: string;
  name: string;
  url: string;
  uploadedAt: Date;
}

const initialSections: SiteSection[] = [
  { id: '1', name: 'Hero Title', content: 'Transformamos sua presença digital', type: 'text' },
  { id: '2', name: 'Hero Subtitle', content: 'Soluções tecnológicas inovadoras para impulsionar seu negócio', type: 'text' },
  { id: '3', name: 'CTA Button', content: 'Fale Conosco', type: 'text' },
  { id: '4', name: 'Sobre Título', content: 'Quem Somos', type: 'text' },
  { id: '5', name: 'Sobre Texto', content: 'Somos uma empresa de tecnologia focada em soluções inovadoras para negócios.', type: 'text' },
  { id: '6', name: 'Logo Principal', content: '/logo.png', type: 'image' },
];

export function SiteEditor() {
  const [sections, setSections] = useState<SiteSection[]>(initialSections);
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [dragActive, setDragActive] = useState(false);

  const handleContentChange = (id: string, content: string) => {
    setSections(sections.map(s => 
      s.id === id ? { ...s, content } : s
    ));
  };

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSaving(false);
  };

  const handlePublish = async () => {
    setIsPublishing(true);
    // Simulate publishing to Git
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsPublishing(false);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleUpload(files[0]);
    }
  };

  const handleUpload = (file: File) => {
    const newImage: UploadedImage = {
      id: Date.now().toString(),
      name: file.name,
      url: URL.createObjectURL(file),
      uploadedAt: new Date(),
    };
    setUploadedImages([...uploadedImages, newImage]);
  };

  const activeSectionData = sections.find(s => s.id === activeSection);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Globe className="w-7 h-7 text-[#22d3ee]" />
            Visual Site Editor
          </h1>
          <p className="text-[#94a3b8] mt-1">Edite o conteúdo do site cmtecnologia.pt</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button 
            variant={showPreview ? 'primary' : 'default'} 
            onClick={() => setShowPreview(!showPreview)}
          >
            <Eye className="w-4 h-4 mr-2" />
            {showPreview ? 'Editar' : 'Preview'}
          </Button>
          <Button variant="default" onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Salvar
          </Button>
          <DeployButton onDeploy={handlePublish} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Editor Panel */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white">Seções do Site</h3>
            </div>
            <CardContent className="p-4 space-y-3">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                    activeSection === section.id 
                      ? 'bg-[#1a1a25] border border-[#22d3ee]/30' 
                      : 'hover:bg-[#1a1a25]/50 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {section.type === 'text' ? (
                      <FileText className="w-5 h-5 text-[#94a3b8]" />
                    ) : (
                      <Image className="w-5 h-5 text-[#94a3b8]" />
                    )}
                    <div className="text-left">
                      <p className="font-medium text-white text-sm">{section.name}</p>
                      <p className="text-xs text-[#64748b] truncate max-w-48">
                        {section.content.substring(0, 40)}...
                      </p>
                    </div>
                  </div>
                  <Badge variant={activeSection === section.id ? 'neon' : 'default'}>
                    {section.type}
                  </Badge>
                </button>
              ))}
            </CardContent>
          </Card>

          {/* Edit Section */}
          <AnimatePresence mode="wait">
            {activeSection && activeSectionData && (
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                <Card>
                  <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
                    <h3 className="font-semibold text-white">
                      Editar: {activeSectionData.name}
                    </h3>
                  </div>
                  <CardContent className="p-4 space-y-4">
                    {activeSectionData.type === 'text' ? (
                      <div>
                        <label className="block text-sm font-medium text-[#94a3b8] mb-2">
                          Conteúdo
                        </label>
                        <textarea
                          value={activeSectionData.content}
                          onChange={(e) => handleContentChange(activeSectionData.id, e.target.value)}
                          className="w-full h-32 bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl p-4 text-white placeholder-[#64748b] resize-none focus:outline-none focus:border-[#22d3ee] focus:ring-1 focus:ring-[#22d3ee]/30"
                          placeholder="Digite o conteúdo..."
                        />
                      </div>
                    ) : (
                      <div
                        onDragEnter={handleDrag}
                        onDragLeave={handleDrag}
                        onDragOver={handleDrag}
                        onDrop={handleDrop}
                        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
                          dragActive 
                            ? 'border-[#22d3ee] bg-[#22d3ee]/5' 
                            : 'border-[rgba(148,163,184,0.2)] hover:border-[#22d3ee]/50'
                        }`}
                      >
                        <Upload className="w-10 h-10 text-[#64748b] mx-auto mb-4" />
                        <p className="text-[#94a3b8] mb-2">
                          Arraste uma imagem ou clique para selecionar
                        </p>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
                          className="hidden"
                          id="image-upload"
                        />
                        <label htmlFor="image-upload">
                          <span className="text-[#22d3ee] cursor-pointer hover:underline">
                            Selecionar arquivo
                          </span>
                        </label>
                      </div>
                    )}
                    
                    <Button variant="primary" onClick={handleSave} disabled={isSaving} className="w-full">
                      {isSaving ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Check className="w-4 h-4 mr-2" />
                      )}
                      Salvar Alterações
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {!activeSection && (
            <Card>
              <CardContent className="p-8 text-center">
                <Globe className="w-12 h-12 text-[#64748b] mx-auto mb-4" />
                <p className="text-[#94a3b8]">
                  Selecione uma seção para editar
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Uploaded Images & Info */}
        <div className="space-y-4">
          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white">Imagens Carregadas</h3>
            </div>
            <CardContent className="p-4">
              {uploadedImages.length > 0 ? (
                <div className="space-y-2">
                  {uploadedImages.map((img) => (
                    <div key={img.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-[#1a1a25]/50">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-[#1a1a25]">
                        <img src={img.url} alt={img.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-white truncate">{img.name}</p>
                        <p className="text-xs text-[#64748b]">
                          {img.uploadedAt.toLocaleTimeString('pt-BR')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-[#64748b] text-center py-4">
                  Nenhuma imagem carregada
                </p>
              )}
            </CardContent>
          </Card>

          <Card variant="glass">
            <CardContent className="p-4">
              <h4 className="font-medium text-white mb-2">Status do Site</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#94a3b8]">Última publicação</span>
                  <span className="text-white">Hoje, 14:30</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#94a3b8]">Status</span>
                  <Badge variant="success">Online</Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#94a3b8]">Versão</span>
                  <span className="text-white">v2.4.1</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
