import { useState, useEffect, useRef } from 'react';
import { Terminal, Play, Pause, Trash2, Download, Info, AlertTriangle, XCircle, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
  agentName?: string;
}

const initialLogs: LogEntry[] = [
  { id: '1', timestamp: new Date(Date.now() - 5000), level: 'info', message: 'Iniciando sistema de agentes...', agentName: 'System' },
  { id: '2', timestamp: new Date(Date.now() - 4000), level: 'info', message: 'Carregando configurações do agente Sofia', agentName: 'System' },
  { id: '3', timestamp: new Date(Date.now() - 3000), level: 'success', message: 'Agente Sofia inicializado com sucesso', agentName: 'Sofia' },
  { id: '4', timestamp: new Date(Date.now() - 2000), level: 'info', message: 'Carregando configurações do agente Marco', agentName: 'System' },
  { id: '5', timestamp: new Date(Date.now() - 1000), level: 'success', message: 'Agente Marco inicializado com sucesso', agentName: 'Marco' },
];

export function LiveLogTerminal() {
  const [logs, setLogs] = useState<LogEntry[]>(initialLogs);
  const [isPlaying, setIsPlaying] = useState(true);
  const [autoScroll, setAutoScroll] = useState(true);
  const terminalRef = useRef<HTMLDivElement>(null);

  // Simulate new log entries
  useEffect(() => {
    if (!isPlaying) return;

    const messages = [
      { level: 'info' as const, message: 'Verificando novas mensagens...' },
      { level: 'info' as const, message: 'Processando lead: João Silva' },
      { level: 'success' as const, message: 'Email enviado com sucesso' },
      { level: 'info' as const, message: 'Agendando follow-up para amanhã' },
      { level: 'warning' as const, message: 'Nenhum horário disponível para hoje' },
      { level: 'success' as const, message: 'Reunião agendada com sucesso' },
      { level: 'info' as const, message: 'Iniciando nutrição de leads...' },
      { level: 'success' as const, message: '15 leads nutridos com sucesso' },
    ];

    const interval = setInterval(() => {
      const randomMessage = messages[Math.floor(Math.random() * messages.length)];
      const agentNames = ['Sofia', 'Marco', 'Ana', 'Lucia'];
      const randomAgent = agentNames[Math.floor(Math.random() * agentNames.length)];
      
      const newLog: LogEntry = {
        id: Date.now().toString(),
        timestamp: new Date(),
        level: randomMessage.level,
        message: randomMessage.message,
        agentName: randomAgent,
      };
      
      setLogs(prev => [...prev.slice(-50), newLog]); // Keep last 50 logs
    }, 3000);

    return () => clearInterval(interval);
  }, [isPlaying]);

  // Auto scroll to bottom
  useEffect(() => {
    if (autoScroll && terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const getLevelIcon = (level: LogEntry['level']) => {
    switch (level) {
      case 'info': return <Info className="w-4 h-4 text-cyan-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'success': return <CheckCircle className="w-4 h-4 text-emerald-400" />;
    }
  };

  const getLevelColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'info': return 'text-cyan-400';
      case 'warning': return 'text-amber-400';
      case 'error': return 'text-red-400';
      case 'success': return 'text-emerald-400';
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  const clearLogs = () => {
    setLogs([]);
  };

  const downloadLogs = () => {
    const logText = logs.map(log => 
      `[${formatTime(log.timestamp)}] [${log.level.toUpperCase()}] ${log.agentName || 'System'}: ${log.message}`
    ).join('\n');
    
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `logs-${new Date().toISOString()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Terminal className="w-7 h-7 text-[#22d3ee]" />
            Live Log Terminal
          </h1>
          <p className="text-[#94a3b8] mt-1">Monitoramento em tempo real dos agentes</p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant={isPlaying ? 'default' : 'primary'} 
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Pausar
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Continuar
              </>
            )}
          </Button>
          <Button variant="default" onClick={clearLogs}>
            <Trash2 className="w-4 h-4 mr-2" />
            Limpar
          </Button>
          <Button variant="default" onClick={downloadLogs}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Terminal */}
      <Card className="overflow-hidden">
        <div className="p-4 border-b border-[rgba(148,163,184,0.1)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-amber-500" />
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
            </div>
            <span className="text-sm text-[#94a3b8] ml-2">terminal</span>
          </div>
          <label className="flex items-center gap-2 text-sm text-[#94a3b8]">
            <input
              type="checkbox"
              checked={autoScroll}
              onChange={(e) => setAutoScroll(e.target.checked)}
              className="rounded bg-[#1a1a25] border-[rgba(148,163,184,0.2)] text-[#22d3ee] focus:ring-[#22d3ee]/30"
            />
            Auto scroll
          </label>
        </div>
        
        <div 
          ref={terminalRef}
          className="h-[500px] overflow-auto bg-[#0a0a0f] p-4 font-mono text-sm"
        >
          {logs.map((log) => (
            <div 
              key={log.id} 
              className="flex items-start gap-3 py-1 hover:bg-[#1a1a25]/30 rounded px-2 -mx-2"
            >
              <span className="text-[#64748b] flex-shrink-0">
                {formatTime(log.timestamp)}
              </span>
              <span className={getLevelColor(log.level)}>
                {getLevelIcon(log.level)}
              </span>
              <span className="text-purple-400 flex-shrink-0">
                [{log.agentName || 'System'}]
              </span>
              <span className="text-white">
                {log.message}
              </span>
            </div>
          ))}
          
          {logs.length === 0 && (
            <div className="text-center text-[#64748b] py-8">
              <Terminal className="w-8 h-8 mx-auto mb-2" />
              <p>Aguardando logs...</p>
            </div>
          )}
        </div>
      </Card>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 text-sm">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-cyan-400" />
          <span className="text-[#94a3b8]">Info</span>
        </div>
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span className="text-[#94a3b8]">Warning</span>
        </div>
        <div className="flex items-center gap-2">
          <XCircle className="w-4 h-4 text-red-400" />
          <span className="text-[#94a3b8]">Error</span>
        </div>
        <div className="flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span className="text-[#94a3b8]">Success</span>
        </div>
      </div>
    </div>
  );
}
