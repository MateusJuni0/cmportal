import React, { useState } from 'react';
import { 
  Palette, 
  Sun, 
  RotateCcw, 
  Box, 
  Lightbulb,
  Maximize2,
  Grid3X3,
  Check,
  RefreshCw
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';

interface SceneSettings {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  lightIntensity: number;
  objectPositionX: number;
  objectPositionY: number;
  objectRotation: number;
  objectScale: number;
  showGrid: boolean;
  autoRotate: boolean;
}

const presetColors = [
  { name: 'Cyber Cyan', primary: '#22d3ee', secondary: '#0891b2' },
  { name: 'Neon Purple', primary: '#a855f7', secondary: '#7c3aed' },
  { name: 'Emerald Glow', primary: '#10b981', secondary: '#059669' },
  { name: 'Sunset Orange', primary: '#f59e0b', secondary: '#d97706' },
  { name: 'Rose Pink', primary: '#ec4899', secondary: '#db2777' },
  { name: 'Ocean Blue', primary: '#3b82f6', secondary: '#2563eb' },
];

export function SceneCustomizer() {
  const [settings, setSettings] = useState<SceneSettings>({
    primaryColor: '#22d3ee',
    secondaryColor: '#0891b2',
    accentColor: '#ffffff',
    lightIntensity: 1,
    objectPositionX: 0,
    objectPositionY: 0,
    objectRotation: 0,
    objectScale: 1,
    showGrid: true,
    autoRotate: true,
  });

  const [isAnimating, setIsAnimating] = useState(false);

  const updateSetting = <K extends keyof SceneSettings>(key: K, value: SceneSettings[K]) => {
    setSettings({ ...settings, [key]: value });
  };

  const applyPreset = (preset: typeof presetColors[0]) => {
    setSettings({
      ...settings,
      primaryColor: preset.primary,
      secondaryColor: preset.secondary,
    });
  };

  const resetSettings = () => {
    setSettings({
      primaryColor: '#22d3ee',
      secondaryColor: '#0891b2',
      accentColor: '#ffffff',
      lightIntensity: 1,
      objectPositionX: 0,
      objectPositionY: 0,
      objectRotation: 0,
      objectScale: 1,
      showGrid: true,
      autoRotate: true,
    });
  };

  const simulateUpdate = () => {
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 1500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Box className="w-7 h-7 text-[#ec4899]" />
            3D Scene Customizer
          </h1>
          <p className="text-[#94a3b8] mt-1">Personalize a cena 3D do site com controles simples</p>
        </div>
        
        <Button variant="default" onClick={resetSettings}>
          <RotateCcw className="w-4 h-4 mr-2" />
          Resetar
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Preview Area */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="overflow-hidden">
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Box className="w-5 h-5 text-[#94a3b8]" />
                <span className="font-medium text-white">Preview da Cena</span>
              </div>
              <Badge variant={isAnimating ? 'warning' : 'success'}>
                {isAnimating ? 'Atualizando...' : 'Sincronizado'}
              </Badge>
            </div>
            
            {/* 3D Canvas Placeholder */}
            <div 
              className="relative h-96 bg-gradient-to-br from-[#0a0a0f] to-[#1a1a25]"
              style={{
                backgroundImage: settings.showGrid 
                  ? `linear-gradient(rgba(34,211,238,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.05) 1px, transparent 1px)`
                  : undefined,
                backgroundSize: '50px 50px',
              }}
            >
              {/* Simulated 3D Object */}
              <motion.div
                className="absolute top-1/2 left-1/2 w-32 h-32 rounded-2xl"
                style={{
                  background: `linear-gradient(135deg, ${settings.primaryColor}, ${settings.secondaryColor})`,
                  boxShadow: `0 0 40px ${settings.primaryColor}40, 0 0 80px ${settings.secondaryColor}20`,
                  x: '-50%',
                  y: '-50%',
                  rotate: settings.objectRotation,
                  scale: settings.objectScale,
                }}
                animate={{
                  x: settings.objectPositionX,
                  y: settings.objectPositionY,
                  rotate: settings.autoRotate ? [settings.objectRotation, settings.objectRotation + 360] : settings.objectRotation,
                }}
                transition={{
                  rotate: {
                    duration: settings.autoRotate ? 10 : 0,
                    repeat: Infinity,
                    ease: 'linear',
                  },
                }}
              >
                {/* Object faces simulation */}
                <div className="absolute inset-0 border-2 border-white/20 rounded-2xl" />
                <div 
                  className="absolute -top-4 -left-4 w-8 h-8 rounded-lg opacity-60"
                  style={{ background: settings.accentColor }}
                />
              </motion.div>

              {/* Light source indicator */}
              <div 
                className="absolute top-4 right-4 w-6 h-6 rounded-full"
                style={{
                  background: `radial-gradient(circle, ${settings.primaryColor} 0%, transparent 70%)`,
                  boxShadow: `0 0 20px ${settings.primaryColor}`,
                }}
              />

              {/* Grid toggle indicator */}
              {settings.showGrid && (
                <div className="absolute bottom-4 left-4 text-xs text-[#64748b]">
                  <Grid3X3 className="w-4 h-4 inline mr-1" />
                  Grid enabled
                </div>
              )}

              {/* Auto rotate indicator */}
              {settings.autoRotate && (
                <div className="absolute bottom-4 right-4">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  >
                    <RefreshCw className="w-4 h-4 text-[#22d3ee]" />
                  </motion.div>
                </div>
              )}
            </div>
          </Card>

          {/* Color Presets */}
          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white flex items-center gap-2">
                <Palette className="w-5 h-5 text-[#a855f7]" />
                Paletas de Cores
              </h3>
            </div>
            <CardContent className="p-4">
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                {presetColors.map((preset) => (
                  <button
                    key={preset.name}
                    onClick={() => applyPreset(preset)}
                    className="relative group p-2 rounded-xl bg-[#1a1a25] hover:bg-[#252532] transition-colors"
                  >
                    <div 
                      className="w-full h-8 rounded-lg mb-1"
                      style={{ background: `linear-gradient(135deg, ${preset.primary}, ${preset.secondary})` }}
                    />
                    <span className="text-xs text-[#94a3b8] group-hover:text-white">
                      {preset.name}
                    </span>
                    {settings.primaryColor === preset.primary && (
                      <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 text-black" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Controls Panel */}
        <div className="space-y-4">
          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white">Cores</h3>
            </div>
            <CardContent className="p-4 space-y-4">
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Cor Primária</span>
                  <span className="text-white font-mono">{settings.primaryColor}</span>
                </label>
                <input
                  type="color"
                  value={settings.primaryColor}
                  onChange={(e) => updateSetting('primaryColor', e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)]"
                />
              </div>
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Cor Secundária</span>
                  <span className="text-white font-mono">{settings.secondaryColor}</span>
                </label>
                <input
                  type="color"
                  value={settings.secondaryColor}
                  onChange={(e) => updateSetting('secondaryColor', e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)]"
                />
              </div>
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Cor de Destaque</span>
                  <span className="text-white font-mono">{settings.accentColor}</span>
                </label>
                <input
                  type="color"
                  value={settings.accentColor}
                  onChange={(e) => updateSetting('accentColor', e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)]"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-amber-400" />
                Iluminação
              </h3>
            </div>
            <CardContent className="p-4 space-y-4">
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Intensidade da Luz</span>
                  <span className="text-white">{(settings.lightIntensity * 100).toFixed(0)}%</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.1"
                  value={settings.lightIntensity}
                  onChange={(e) => updateSetting('lightIntensity', parseFloat(e.target.value))}
                  className="w-full accent-[#22d3ee]"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white flex items-center gap-2">
                <Maximize2 className="w-5 h-5 text-cyan-400" />
                Posição do Objeto
              </h3>
            </div>
            <CardContent className="p-4 space-y-4">
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Posição X</span>
                  <span className="text-white">{settings.objectPositionX}px</span>
                </label>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.objectPositionX}
                  onChange={(e) => updateSetting('objectPositionX', parseInt(e.target.value))}
                  className="w-full accent-[#22d3ee]"
                />
              </div>
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Posição Y</span>
                  <span className="text-white">{settings.objectPositionY}px</span>
                </label>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.objectPositionY}
                  onChange={(e) => updateSetting('objectPositionY', parseInt(e.target.value))}
                  className="w-full accent-[#22d3ee]"
                />
              </div>
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Rotação</span>
                  <span className="text-white">{settings.objectRotation}°</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={settings.objectRotation}
                  onChange={(e) => updateSetting('objectRotation', parseInt(e.target.value))}
                  className="w-full accent-[#22d3ee]"
                />
              </div>
              <div>
                <label className="flex items-center justify-between text-sm text-[#94a3b8] mb-2">
                  <span>Escala</span>
                  <span className="text-white">{settings.objectScale.toFixed(1)}x</span>
                </label>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={settings.objectScale}
                  onChange={(e) => updateSetting('objectScale', parseFloat(e.target.value))}
                  className="w-full accent-[#22d3ee]"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white">Opções</h3>
            </div>
            <CardContent className="p-4 space-y-3">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-sm text-[#94a3b8]">Mostrar Grid</span>
                <input
                  type="checkbox"
                  checked={settings.showGrid}
                  onChange={(e) => updateSetting('showGrid', e.target.checked)}
                  className="w-5 h-5 rounded bg-[#1a1a25] border-[rgba(148,163,184,0.2)] text-[#22d3ee] focus:ring-[#22d3ee]/30"
                />
              </label>
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-sm text-[#94a3b8]">Auto Rotação</span>
                <input
                  type="checkbox"
                  checked={settings.autoRotate}
                  onChange={(e) => updateSetting('autoRotate', e.target.checked)}
                  className="w-5 h-5 rounded bg-[#1a1a25] border-[rgba(148,163,184,0.2)] text-[#22d3ee] focus:ring-[#22d3ee]/30"
                />
              </label>
            </CardContent>
          </Card>

          <Button variant="primary" className="w-full" onClick={simulateUpdate}>
            <Check className="w-4 h-4 mr-2" />
            Aplicar Alterações
          </Button>
        </div>
      </div>
    </div>
  );
}
