import { useState } from 'react';
import { Sparkles, Image, FileText, Video, Loader2, Wand2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/Tabs';
import { Badge } from '@/components/ui/Badge';

type GenerationStatus = 'idle' | 'generating' | 'completed' | 'error';

interface GeneratedItem {
  id: string;
  type: 'image' | 'copy' | 'video';
  prompt: string;
  result?: string;
  status: GenerationStatus;
}

export function CreativeLab() {
  const [items, setItems] = useState<GeneratedItem[]>([]);
  const [activeTab, setActiveTab] = useState('image');
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    
    const newItem: GeneratedItem = {
      id: Date.now().toString(),
      type: activeTab as 'image' | 'copy' | 'video',
      prompt,
      status: 'generating',
    };
    
    setItems([newItem, ...items]);
    setPrompt('');
    
    // Simulate generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setItems(items.map(item => 
      item.id === newItem.id 
        ? { 
            ...item, 
            status: 'completed',
            result: activeTab === 'copy' ? 'Seu copy gerado com sucesso! Isso é um exemplo de texto que seria gerado pela IA.' : undefined
          } 
        : item
    ));
    setIsGenerating(false);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'image': return <Image className="w-5 h-5" />;
      case 'copy': return <FileText className="w-5 h-5" />;
      case 'video': return <Video className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Sparkles className="w-7 h-7 text-[#a855f7]" />
            Multimodal Creative Lab
          </h1>
          <p className="text-[#94a3b8] mt-1">Gere imagens, copies e vídeos para prospecção</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="image" onValueChange={setActiveTab}>
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="image" className="flex items-center gap-2">
            <Image className="w-4 h-4" />
            Imagem
          </TabsTrigger>
          <TabsTrigger value="copy" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Copy
          </TabsTrigger>
          <TabsTrigger value="video" className="flex items-center gap-2">
            <Video className="w-4 h-4" />
            Vídeo
          </TabsTrigger>
        </TabsList>

        {/* Image Tab */}
        <TabsContent value="image">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-2">
                  Descreva a imagem que deseja gerar
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Ex: Uma pessoa usando laptop em um escritório moderno com fundo azul neon..."
                  className="w-full h-32 bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl p-4 text-white placeholder-[#64748b] resize-none focus:outline-none focus:border-[#a855f7] focus:ring-1 focus:ring-[#a855f7]/30"
                />
              </div>
              
              <Button 
                variant="primary" 
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className="w-full"
              >
                {isGenerating ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Wand2 className="w-4 h-4 mr-2" />
                )}
                {isGenerating ? 'Gerando...' : 'Gerar Imagem'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Copy Tab */}
        <TabsContent value="copy">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-2">
                  Descreva o copy que deseja gerar
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Ex: Copy para email de prospecção sobre serviços de tecnologia para pequenas empresas..."
                  className="w-full h-32 bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl p-4 text-white placeholder-[#64748b] resize-none focus:outline-none focus:border-[#a855f7] focus:ring-1 focus:ring-[#a855f7]/30"
                />
              </div>
              
              <Button 
                variant="primary" 
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className="w-full"
              >
                {isGenerating ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Wand2 className="w-4 h-4 mr-2" />
                )}
                {isGenerating ? 'Gerando...' : 'Gerar Copy'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Video Tab */}
        <TabsContent value="video">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-2">
                  Descreva o vídeo que deseja gerar
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Ex: Vídeo curto mostrando os benefícios do produto com transições suaves..."
                  className="w-full h-32 bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl p-4 text-white placeholder-[#64748b] resize-none focus:outline-none focus:border-[#a855f7] focus:ring-1 focus:ring-[#a855f7]/30"
                />
              </div>
              
              <Button 
                variant="primary" 
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className="w-full"
              >
                {isGenerating ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Wand2 className="w-4 h-4 mr-2" />
                )}
                {isGenerating ? 'Gerando...' : 'Gerar Vídeo'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Generated Results */}
      {items.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {items.map((item) => (
            <Card key={item.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#a855f7]/10 flex items-center justify-center text-[#a855f7]">
                      {getTypeIcon(item.type)}
                    </div>
                    <span className="font-medium text-white capitalize">{item.type}</span>
                  </div>
                  <Badge variant={item.status === 'completed' ? 'success' : item.status === 'generating' ? 'warning' : 'default'}>
                    {item.status === 'completed' ? 'Concluído' : item.status === 'generating' ? 'Gerando...' : item.status}
                  </Badge>
                </div>
                
                <p className="text-sm text-[#94a3b8] mb-3">Prompt: {item.prompt}</p>
                
                {item.status === 'generating' && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 text-[#a855f7] animate-spin" />
                  </div>
                )}
                
                {item.status === 'completed' && item.type === 'copy' && (
                  <div className="p-3 bg-[#0a0a0f] rounded-lg">
                    <p className="text-sm text-white">{item.result}</p>
                  </div>
                )}
                
                {item.status === 'completed' && item.type === 'image' && (
                  <div className="h-48 bg-gradient-to-br from-[#a855f7]/20 to-[#22d3ee]/20 rounded-lg flex items-center justify-center">
                    <Image className="w-12 h-12 text-[#64748b]" />
                  </div>
                )}
                
                {item.status === 'completed' && item.type === 'video' && (
                  <div className="h-48 bg-gradient-to-br from-[#22d3ee]/20 to-[#a855f7]/20 rounded-lg flex items-center justify-center">
                    <Video className="w-12 h-12 text-[#64748b]" />
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
