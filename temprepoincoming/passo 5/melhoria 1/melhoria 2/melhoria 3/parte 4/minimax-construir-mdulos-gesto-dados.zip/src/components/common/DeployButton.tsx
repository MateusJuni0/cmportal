import React, { useState } from 'react';
import { Rocket, Check, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/utils/cn';

interface DeployButtonProps {
  onDeploy?: () => void;
}

type DeployState = 'idle' | 'deploying' | 'success' | 'error';

export function DeployButton({ onDeploy }: DeployButtonProps) {
  const [state, setState] = useState<DeployState>('idle');
  const [progress, setProgress] = useState(0);

  const handleDeploy = async () => {
    if (state !== 'idle') return;
    
    setState('deploying');
    setProgress(0);

    // Simulate deployment progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setState('success');
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 300);

    // Simulate API call
    setTimeout(() => {
      if (onDeploy) onDeploy();
    }, 500);
  };

  const handleReset = () => {
    setState('idle');
    setProgress(0);
  };

  return (
    <div className="relative">
      <motion.button
        onClick={handleDeploy}
        disabled={state !== 'idle'}
        className={cn(
          'relative overflow-hidden px-6 py-3 rounded-xl font-medium transition-all duration-300',
          'flex items-center gap-2',
          state === 'idle' && 'bg-gradient-to-r from-[#22d3ee] to-[#a855f7] text-white hover:shadow-lg hover:shadow-cyan-500/25',
          state === 'deploying' && 'bg-[#1a1a25] text-white cursor-wait',
          state === 'success' && 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30',
          state === 'error' && 'bg-red-500/20 text-red-400 border border-red-500/30'
        )}
        whileTap={{ scale: 0.98 }}
      >
        <AnimatePresence mode="wait">
          {state === 'idle' && (
            <motion.div
              key="idle"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-2"
            >
              <Rocket className="w-5 h-5" />
              <span>Deploy</span>
            </motion.div>
          )}

          {state === 'deploying' && (
            <motion.div
              key="deploying"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-2"
            >
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Deploying...</span>
            </motion.div>
          )}

          {state === 'success' && (
            <motion.div
              key="success"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-2"
            >
              <Check className="w-5 h-5" />
              <span>Deployado!</span>
            </motion.div>
          )}

          {state === 'error' && (
            <motion.div
              key="error"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-2"
            >
              <X className="w-5 h-5" />
              <span>Erro</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Progress Bar */}
        {state === 'deploying' && (
          <motion.div
            className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-cyan-400 to-purple-500"
            initial={{ width: '0%' }}
            animate={{ width: `${Math.min(progress, 100)}%` }}
            style={{ maxWidth: '100%' }}
          />
        )}
      </motion.button>

      {/* Success/Error Actions */}
      <AnimatePresence>
        {state === 'success' && (
          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            onClick={handleReset}
            className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs text-emerald-400 hover:text-emerald-300"
          >
            Clique para resetar
          </motion.button>
        )}

        {state === 'error' && (
          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            onClick={handleReset}
            className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs text-red-400 hover:text-red-300"
          >
            Tentar novamente
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
