import { useState, useRef } from 'react';
import { Upload, Link2, FileText, CheckCircle, Loader2, AlertCircle, X } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';

interface Document {
  id: string;
  name: string;
  type: 'pdf' | 'url';
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress?: number;
}

export function AITrainingGround() {
  const [documents, setDocuments] = useState<Document[]>([
    { id: '1', name: 'Manual de Produtos 2024.pdf', type: 'pdf', status: 'completed' },
    { id: '2', name: 'FAQ clientes.pdf', type: 'pdf', status: 'completed' },
  ]);
  const [urlInput, setUrlInput] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFileUpload(files[0]);
    }
  };

  const handleFileUpload = (file: File) => {
    const newDoc: Document = {
      id: Date.now().toString(),
      name: file.name,
      type: 'pdf',
      status: 'pending',
    };
    
    setDocuments([newDoc, ...documents]);
    processDocument(newDoc.id);
  };

  const handleUrlSubmit = () => {
    if (!urlInput.trim()) return;
    
    const newDoc: Document = {
      id: Date.now().toString(),
      name: urlInput,
      type: 'url',
      status: 'pending',
    };
    
    setDocuments([newDoc, ...documents]);
    setUrlInput('');
    processDocument(newDoc.id);
  };

  const processDocument = async (id: string) => {
    // Update to processing
    setDocuments(documents.map(doc => 
      doc.id === id ? { ...doc, status: 'processing', progress: 0 } : doc
    ));
    
    // Simulate processing progress
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 200));
      setDocuments(documents.map(doc => 
        doc.id === id ? { ...doc, progress: i } : doc
      ));
    }
    
    // Complete
    setDocuments(documents.map(doc => 
      doc.id === id ? { ...doc, status: 'completed', progress: 100 } : doc
    ));
  };

  const removeDocument = (id: string) => {
    setDocuments(documents.filter(doc => doc.id !== id));
  };

  const getStatusIcon = (status: Document['status']) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-5 h-5 text-emerald-400" />;
      case 'processing': return <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />;
      case 'error': return <AlertCircle className="w-5 h-5 text-red-400" />;
      default: return <Loader2 className="w-5 h-5 text-[#64748b]" />;
    }
  };

  const getStatusBadge = (status: Document['status']) => {
    switch (status) {
      case 'completed': return <Badge variant="success">Concluído</Badge>;
      case 'processing': return <Badge variant="warning">Processando</Badge>;
      case 'error': return <Badge variant="danger">Erro</Badge>;
      default: return <Badge variant="default">Pendente</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <FileText className="w-7 h-7 text-[#10b981]" />
            AI Training Ground
          </h1>
          <p className="text-[#94a3b8] mt-1">Treine os agentes com PDFs e Links</p>
        </div>
      </div>

      {/* Upload Area */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* File Upload */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Upload de Arquivos</h3>
            
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                dragActive 
                  ? 'border-[#10b981] bg-[#10b981]/5' 
                  : 'border-[rgba(148,163,184,0.2)] hover:border-[#10b981]/50'
              }`}
            >
              <Upload className="w-10 h-10 text-[#64748b] mx-auto mb-4" />
              <p className="text-[#94a3b8] mb-2">
                Arraste arquivos ou clique para selecionar
              </p>
              <p className="text-xs text-[#64748b]">
                Formatos suportados: PDF
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                className="hidden"
              />
            </div>
          </CardContent>
        </Card>

        {/* URL Input */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Adicionar URL</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-2">
                  URL para processar
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="https://exemplo.com/pagina"
                    className="flex-1 bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-4 py-2.5 text-white placeholder-[#64748b] focus:outline-none focus:border-[#10b981] focus:ring-1 focus:ring-[#10b981]/30"
                  />
                  <Button 
                    variant="primary" 
                    onClick={handleUrlSubmit}
                    disabled={!urlInput.trim()}
                  >
                    <Link2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="p-4 bg-[#1a1a25] rounded-xl">
                <h4 className="font-medium text-white mb-2">Exemplos de URLs</h4>
                <ul className="space-y-1 text-sm text-[#94a3b8]">
                  <li>• Páginas de FAQ</li>
                  <li>• Políticas de privacidade</li>
                  <li>• Páginas de preços</li>
                  <li>• Documentação de produtos</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Documents List */}
      <Card>
        <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
          <h3 className="font-semibold text-white">Documentos Processados</h3>
        </div>
        
        {documents.length > 0 ? (
          <div className="divide-y divide-[rgba(148,163,184,0.1)]">
            {documents.map((doc) => (
              <div key={doc.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[#1a1a25] flex items-center justify-center">
                    {doc.type === 'pdf' ? (
                      <FileText className="w-5 h-5 text-red-400" />
                    ) : (
                      <Link2 className="w-5 h-5 text-cyan-400" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-white truncate max-w-md">
                      {doc.name}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      {getStatusBadge(doc.status)}
                      {doc.status === 'processing' && doc.progress !== undefined && (
                        <span className="text-xs text-[#64748b]">{doc.progress}%</span>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  {doc.status === 'processing' && doc.progress !== undefined && (
                    <div className="w-24 h-1.5 bg-[#1a1a25] rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-[#10b981] to-[#22d3ee] rounded-full transition-all"
                        style={{ width: `${doc.progress}%` }}
                      />
                    </div>
                  )}
                  {getStatusIcon(doc.status)}
                  <button
                    onClick={() => removeDocument(doc.id)}
                    className="p-1 text-[#64748b] hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 text-[#64748b] mx-auto mb-4" />
            <p className="text-[#94a3b8]">Nenhum documento processado ainda</p>
          </CardContent>
        )}
      </Card>
    </div>
  );
}
