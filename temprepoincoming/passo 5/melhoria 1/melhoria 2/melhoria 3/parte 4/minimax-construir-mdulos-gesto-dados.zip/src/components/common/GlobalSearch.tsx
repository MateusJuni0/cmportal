import React, { useState, useEffect } from 'react';
import { Search, X, FileText, Users, Bot, Folder, ArrowRight } from 'lucide-react';
import { cn } from '@/utils/cn';

interface SearchResult {
  id: string;
  title: string;
  type: 'lead' | 'agent' | 'file' | 'page';
  description?: string;
  icon: React.ReactNode;
}

// Mock search results
const mockResults: SearchResult[] = [
  { id: '1', title: 'João Silva - TechStart Brasil', type: 'lead', description: 'Score: 92', icon: <Users className="w-4 h-4" /> },
  { id: '2', title: 'Maria Santos - Digital Solutions', type: 'lead', description: 'Score: 85', icon: <Users className="w-4 h-4" /> },
  { id: '3', title: 'Sofia - Agente de Atendimento', type: 'agent', description: 'Online', icon: <Bot className="w-4 h-4" /> },
  { id: '4', title: 'Marco - Agente de Vendas', type: 'agent', description: 'Online', icon: <Bot className="w-4 h-4" /> },
  { id: '5', title: 'Manual de Produtos 2024.pdf', type: 'file', description: 'Documentos', icon: <FileText className="w-4 h-4" /> },
  { id: '6', title: 'FAQ clientes.pdf', type: 'file', description: 'Documentos', icon: <FileText className="w-4 h-4" /> },
  { id: '7', title: 'Dashboard', type: 'page', description: 'Página', icon: <Folder className="w-4 h-4" /> },
  { id: '8', title: 'Leads Sniper', type: 'page', description: 'Página', icon: <Folder className="w-4 h-4" /> },
];

const typeColors: Record<string, string> = {
  lead: 'text-cyan-400 bg-cyan-400/10',
  agent: 'text-purple-400 bg-purple-400/10',
  file: 'text-amber-400 bg-amber-400/10',
  page: 'text-emerald-400 bg-emerald-400/10',
};

interface GlobalSearchProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (page: string) => void;
}

export function GlobalSearch({ isOpen, onClose, onNavigate }: GlobalSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    if (query.length > 0) {
      const filtered = mockResults.filter(
        (result) =>
          result.title.toLowerCase().includes(query.toLowerCase()) ||
          result.description?.toLowerCase().includes(query.toLowerCase())
      );
      setResults(filtered);
      setSelectedIndex(0);
    } else {
      setResults([]);
    }
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (!isOpen) {
          // This will be handled by the parent component
        }
      }
      
      if (!isOpen) return;

      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.min(prev + 1, results.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.max(prev - 1, 0));
      } else if (e.key === 'Enter' && results[selectedIndex]) {
        // Handle selection
        if (onNavigate) {
          if (results[selectedIndex].type === 'lead') {
            onNavigate('leads');
          } else if (results[selectedIndex].type === 'agent') {
            onNavigate('agent-factory');
          }
        }
        onClose();
        setQuery('');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, results, selectedIndex, onNavigate]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-2xl glass rounded-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[rgba(148,163,184,0.1)]">
          <Search className="w-5 h-5 text-[#64748b]" />
          <input
            type="text"
            placeholder="Buscar leads, agentes, arquivos..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-white placeholder-[#64748b] outline-none text-sm"
            autoFocus
          />
          <kbd className="hidden sm:inline-flex items-center gap-1 px-2 py-1 text-xs text-[#64748b] bg-[#1a1a25] rounded-lg border border-[rgba(148,163,184,0.1)]">
            ESC
          </kbd>
        </div>

        {/* Results */}
        {results.length > 0 && (
          <div className="max-h-96 overflow-y-auto p-2">
            {['lead', 'agent', 'file', 'page'].map((type) => {
              const typeResults = results.filter((r) => r.type === type);
              if (typeResults.length === 0) return null;
              
              return (
                <div key={type} className="mb-2">
                  <p className="px-3 py-2 text-xs font-medium text-[#64748b] uppercase tracking-wider">
                    {type === 'lead' ? 'Leads' : type === 'agent' ? 'Agentes' : type === 'file' ? 'Arquivos' : 'Páginas'}
                  </p>
                  {typeResults.map((result, index) => {
                    const globalIndex = results.indexOf(result);
                    const isSelected = globalIndex === selectedIndex;
                    
                    return (
                      <button
                        key={result.id}
                        onClick={() => {
                          if (onNavigate) {
                            if (result.type === 'lead') onNavigate('leads');
                            else if (result.type === 'agent') onNavigate('agent-factory');
                          }
                          onClose();
                          setQuery('');
                        }}
                        className={cn(
                          'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors',
                          isSelected ? 'bg-[#1a1a25] text-white' : 'text-[#94a3b8] hover:bg-[#1a1a25]/50 hover:text-white'
                        )}
                      >
                        <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center', typeColors[result.type])}>
                          {result.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{result.title}</p>
                          {result.description && (
                            <p className="text-xs text-[#64748b]">{result.description}</p>
                          )}
                        </div>
                        {isSelected && (
                          <ArrowRight className="w-4 h-4 text-[#22d3ee]" />
                        )}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        )}

        {/* Empty State / Hint */}
        {query.length === 0 && (
          <div className="p-6 text-center">
            <p className="text-[#64748b] text-sm">
              Comece a digitar para buscar no sistema...
            </p>
            <div className="flex items-center justify-center gap-4 mt-4">
              <div className="flex items-center gap-1">
                <kbd className="px-2 py-1 text-xs text-[#64748b] bg-[#1a1a25] rounded-lg border border-[rgba(148,163,184,0.1)]">
                  ↑
                </kbd>
                <kbd className="px-2 py-1 text-xs text-[#64748b] bg-[#1a1a25] rounded-lg border border-[rgba(148,163,184,0.1)]">
                  ↓
                </kbd>
                <span className="text-xs text-[#64748b] ml-1">navegar</span>
              </div>
              <div className="flex items-center gap-1">
                <kbd className="px-2 py-1 text-xs text-[#64748b] bg-[#1a1a25] rounded-lg border border-[rgba(148,163,184,0.1)]">
                  Enter
                </kbd>
                <span className="text-xs text-[#64748b] ml-1">selecionar</span>
              </div>
            </div>
          </div>
        )}

        {/* No Results */}
        {query.length > 0 && results.length === 0 && (
          <div className="p-6 text-center">
            <p className="text-[#64748b] text-sm">
              Nenhum resultado encontrado para "{query}"
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
