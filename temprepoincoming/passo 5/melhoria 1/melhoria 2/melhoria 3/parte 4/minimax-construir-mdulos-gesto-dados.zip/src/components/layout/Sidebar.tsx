import { 
  LayoutDashboard, 
  Users, 
  DollarSign, 
  MessageCircle, 
  Bot, 
  Sparkles, 
  BookOpen,
  Terminal,
  Settings,
  Globe,
  Layout,
  Box,
  GitBranch,
  X
} from 'lucide-react';
import { cn } from '@/utils/cn';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'leads', label: 'Leads Sniper', icon: Users },
  { id: 'financial', label: 'Financial Command', icon: DollarSign },
  { id: 'clients', label: 'Client Management', icon: Users },
  { id: 'whatsapp', label: 'WhatsApp Warming', icon: MessageCircle },
  { id: 'creative-lab', label: 'Creative Lab', icon: Sparkles },
  { id: 'agent-factory', label: 'Agent Factory', icon: Bot },
  { id: 'ai-training', label: 'AI Training', icon: BookOpen },
  { id: 'logs', label: 'Live Logs', icon: Terminal },
];

const settingsItems = [
  { id: 'site-editor', label: 'Site Editor (CMS)', icon: Globe },
  { id: 'lp-builder', label: 'LP Builder', icon: Layout },
  { id: '3d-customizer', label: '3D Customizer', icon: Box },
  { id: 'git-sync', label: 'Git Sync', icon: GitBranch },
];

export function Sidebar({ isOpen, onClose, currentPage, onNavigate }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full w-64 bg-[#0a0a0f] border-r border-[rgba(148,163,184,0.1)] transition-transform duration-300',
          'lg:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Logo */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-[rgba(148,163,184,0.1)]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#22d3ee] to-[#a855f7] flex items-center justify-center">
              <span className="text-white font-bold text-sm">CM</span>
            </div>
            <span className="text-white font-semibold">Sovereign</span>
          </div>
          <button 
            onClick={onClose}
            className="lg:hidden p-1 text-[#94a3b8] hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        {/* Navigation */}
        <nav className="p-4 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
                  isActive 
                    ? 'bg-gradient-to-r from-[#22d3ee]/10 to-[#a855f7]/10 text-white border border-[rgba(34,211,238,0.2)]' 
                    : 'text-[#94a3b8] hover:text-white hover:bg-[#1a1a25]'
                )}
              >
                <Icon className={cn('w-5 h-5', isActive && 'text-[#22d3ee]')} />
                {item.label}
              </button>
            );
          })}
        </nav>
        
        {/* Settings Navigation */}
        <div className="absolute bottom-20 left-0 right-0 px-4">
          <div className="text-xs font-medium text-[#64748b] uppercase tracking-wider mb-2 px-3">
            Ferramentas
          </div>
          <div className="space-y-1">
            {settingsItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    onClose();
                  }}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200',
                    isActive 
                      ? 'bg-gradient-to-r from-[#22d3ee]/10 to-[#a855f7]/10 text-white border border-[rgba(34,211,238,0.2)]' 
                      : 'text-[#94a3b8] hover:text-white hover:bg-[#1a1a25]'
                  )}
                >
                  <Icon className={cn('w-4 h-4', isActive && 'text-[#22d3ee]')} />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
        
        {/* Settings */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-[rgba(148,163,184,0.1)]">
          <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[#94a3b8] hover:text-white hover:bg-[#1a1a25] transition-all duration-200">
            <Settings className="w-5 h-5" />
            Configurações
          </button>
        </div>
      </aside>
    </>
  );
}
