import { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { GlobalSearch } from '@/components/common/GlobalSearch';

// Dashboard pages
import { LeadsDashboard } from '@/pages/dashboard/leads/LeadsDashboard';
import { FinancialDashboard } from '@/pages/dashboard/financial/FinancialDashboard';
import { ClientsDashboard } from '@/pages/dashboard/clients/ClientsDashboard';
import { WhatsAppDashboard } from '@/pages/dashboard/whatsapp/WhatsAppDashboard';

// Creative Lab
import { CreativeLab } from '@/pages/creative-lab/CreativeLab';

// Agent Factory
import { AgentFactory } from '@/pages/agents/factory/AgentFactory';

// AI Training
import { AITrainingGround } from '@/pages/ai-training/AITrainingGround';

// Live Logs
import { LiveLogTerminal } from '@/components/common/LiveLogTerminal';

// Settings Tools
import { SiteEditor } from '@/pages/cms/SiteEditor';
import { LandingPageBuilder } from '@/pages/lp-builder/LandingPageBuilder';
import { SceneCustomizer } from '@/pages/settings/3d-customizer/SceneCustomizer';
import { GitSyncTool } from '@/pages/settings/git-sync/GitSyncTool';

// Main Dashboard (home)
function MainDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-[#94a3b8] mt-1">Visão geral do Sovereign Sales Engine</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-cyan-400" fill="none0 0 " viewBox="24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">+12%</span>
          </div>
          <p className="text-2xl font-bold text-white">1,234</p>
          <p className="text-sm text-[#94a3b8]">Total de Leads</p>
        </div>
        
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">+8%</span>
          </div>
          <p className="text-2xl font-bold text-white">R$ 52,000</p>
          <p className="text-sm text-[#94a3b8]">Receita Mensal</p>
        </div>
        
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">+5%</span>
          </div>
          <p className="text-2xl font-bold text-white">48</p>
          <p className="text-sm text-[#94a3b8]">Clientes Ativos</p>
        </div>
        
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">+15%</span>
          </div>
          <p className="text-2xl font-bold text-white">3,456</p>
          <p className="text-sm text-[#94a3b8]">Mensagens WhatsApp</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Atividade Recente</h3>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center">
                  <span className="text-xs font-medium text-white">{i}</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-white">Novo lead qualificado</p>
                  <p className="text-xs text-[#64748b]">há {i * 5} minutos</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="glass rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Agentes Ativos</h3>
          <div className="space-y-4">
            {['Sofia', 'Marco', 'Ana', 'Lucia'].map((name, i) => (
              <div key={name} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
                    <span className="text-xs font-medium text-white">{name[0]}</span>
                  </div>
                  <span className="text-sm text-white">{name}</span>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${i < 3 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                  {i < 3 ? 'Online' : 'Treinando'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [searchOpen, setSearchOpen] = useState(false);

  // Handle Cmd+K to open search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <MainDashboard />;
      case 'leads':
        return <LeadsDashboard />;
      case 'financial':
        return <FinancialDashboard />;
      case 'clients':
        return <ClientsDashboard />;
      case 'whatsapp':
        return <WhatsAppDashboard />;
      case 'creative-lab':
        return <CreativeLab />;
      case 'agent-factory':
        return <AgentFactory />;
      case 'ai-training':
        return <AITrainingGround />;
      case 'logs':
        return <LiveLogTerminal />;
      case 'site-editor':
        return <SiteEditor />;
      case 'lp-builder':
        return <LandingPageBuilder />;
      case '3d-customizer':
        return <SceneCustomizer />;
      case 'git-sync':
        return <GitSyncTool />;
      default:
        return <MainDashboard />;
    }
  };

  return (
    <>
      <Layout
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onSearchClick={() => setSearchOpen(true)}
      >
        {renderPage()}
      </Layout>
      
      <GlobalSearch
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onNavigate={setCurrentPage}
      />
    </>
  );
}
