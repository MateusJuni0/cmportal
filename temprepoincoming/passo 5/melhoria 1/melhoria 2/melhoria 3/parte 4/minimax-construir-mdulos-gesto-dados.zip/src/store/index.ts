import { create } from 'zustand';
import { Lead, Client, Agent, TrainingDocument } from '@/types';
import { mockLeads, mockClients, mockAgents, mockTrainingDocuments } from '@/data/mockData';

interface AppState {
  // Navigation
  currentPage: string;
  setCurrentPage: (page: string) => void;
  
  // Leads
  leads: Lead[];
  filteredLeads: Lead[];
  leadFilters: {
    source: string | null;
    search: string;
  };
  setLeadFilters: (filters: Partial<{ source: string | null; search: string }>) => void;
  
  // Clients
  clients: Client[];
  filteredClients: Client[];
  clientFilters: {
    status: string | null;
    search: string;
  };
  setClientFilters: (filters: Partial<{ status: string | null; search: string }>) => void;
  
  // Agents
  agents: Agent[];
  addAgent: (agent: Agent) => void;
  
  // Training
  trainingDocuments: TrainingDocument[];
  addTrainingDocument: (doc: TrainingDocument) => void;
  updateDocumentStatus: (id: string, status: TrainingDocument['status']) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  // Navigation
  currentPage: 'dashboard',
  setCurrentPage: (page) => set({ currentPage: page }),
  
  // Leads
  leads: mockLeads,
  filteredLeads: mockLeads,
  leadFilters: {
    source: null,
    search: '',
  },
  setLeadFilters: (filters) => {
    const newFilters = { ...get().leadFilters, ...filters };
    const filtered = mockLeads.filter((lead) => {
      const matchesSource = !newFilters.source || lead.source === newFilters.source;
      const matchesSearch = !newFilters.search || 
        lead.name.toLowerCase().includes(newFilters.search.toLowerCase()) ||
        lead.company.toLowerCase().includes(newFilters.search.toLowerCase()) ||
        lead.email.toLowerCase().includes(newFilters.search.toLowerCase());
      return matchesSource && matchesSearch;
    });
    set({ leadFilters: newFilters, filteredLeads: filtered });
  },
  
  // Clients
  clients: mockClients,
  filteredClients: mockClients,
  clientFilters: {
    status: null,
    search: '',
  },
  setClientFilters: (filters) => {
    const newFilters = { ...get().clientFilters, ...filters };
    const filtered = mockClients.filter((client) => {
      const matchesStatus = !newFilters.status || client.status === newFilters.status;
      const matchesSearch = !newFilters.search || 
        client.name.toLowerCase().includes(newFilters.search.toLowerCase()) ||
        client.company.toLowerCase().includes(newFilters.search.toLowerCase()) ||
        client.email.toLowerCase().includes(newFilters.search.toLowerCase());
      return matchesStatus && matchesSearch;
    });
    set({ clientFilters: newFilters, filteredClients: filtered });
  },
  
  // Agents
  agents: mockAgents,
  addAgent: (agent) => set((state) => ({ agents: [...state.agents, agent] })),
  
  // Training
  trainingDocuments: mockTrainingDocuments,
  addTrainingDocument: (doc) => set((state) => ({ 
    trainingDocuments: [...state.trainingDocuments, doc] 
  })),
  updateDocumentStatus: (id, status) => set((state) => ({
    trainingDocuments: state.trainingDocuments.map((doc) =>
      doc.id === id ? { ...doc, status, processedAt: status === 'completed' ? new Date() : doc.processedAt } : doc
    ),
  })),
}));
