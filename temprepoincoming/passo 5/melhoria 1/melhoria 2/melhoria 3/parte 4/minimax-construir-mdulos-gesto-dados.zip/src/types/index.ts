// Types for the Sovereign Sales Engine

export interface Lead {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  score: number;
  source: 'instagram' | 'linkedin' | 'zaask' | 'google' | 'direct';
  status: 'new' | 'contacted' | 'qualified' | 'proposal' | 'closed';
  createdAt: Date;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  company: string;
  phone: string;
  status: 'active' | 'trial' | 'inactive' | 'churned';
  plan: 'starter' | 'professional' | 'enterprise';
  startDate: Date;
  trialEndDate?: Date;
  monthlyValue: number;
}

export interface FinancialData {
  date: string;
  revenue: number;
  costs: number;
  profit: number;
  apiCosts: number;
}

export interface WhatsAppAccount {
  id: string;
  phoneNumber: string;
  status: 'active' | 'warming' | 'limited' | 'banned';
  messagesSent: number;
  messagesReceived: number;
  warmingProgress: number;
  lastActivity: Date;
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  personality: string;
  skills: string[];
  status: 'online' | 'offline' | 'training';
  avatar?: string;
  createdAt: Date;
}

export interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
  agentId?: string;
}

export interface TrainingDocument {
  id: string;
  name: string;
  type: 'pdf' | 'url' | 'text';
  status: 'pending' | 'processing' | 'completed' | 'error';
  uploadedAt: Date;
  processedAt?: Date;
}

export interface GeneratedContent {
  id: string;
  type: 'image' | 'copy' | 'video';
  prompt: string;
  result?: string;
  status: 'pending' | 'generating' | 'completed' | 'error';
  createdAt: Date;
}
