import { Menu, Bell, Search, User } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
  onSearchClick: () => void;
}

export function Header({ onMenuClick, onSearchClick }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 h-16 bg-[#0a0a0f]/80 backdrop-blur-xl border-b border-[rgba(148,163,184,0.1)]">
      <div className="flex items-center justify-between h-full px-4 lg:px-6">
        {/* Left side */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onMenuClick}
            className="lg:hidden p-2 text-[#94a3b8] hover:text-white"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="hidden sm:block">
            <h1 className="text-lg font-semibold text-white">
              Sovereign Sales Engine
            </h1>
          </div>
        </div>
        
        {/* Right side */}
        <div className="flex items-center gap-3">
          {/* Search - Cmd+K Trigger */}
          <button 
            onClick={onSearchClick}
            className="hidden md:flex items-center gap-2 bg-[#12121a] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-[#64748b] hover:border-[#22d3ee]/30 transition-all"
          >
            <Search className="w-4 h-4" />
            <span>Buscar...</span>
            <div className="flex items-center gap-1 ml-2">
              <kbd className="px-1.5 py-0.5 text-xs bg-[#1a1a25] rounded border border-[rgba(148,163,184,0.1)]">
                ⌘
              </kbd>
              <kbd className="px-1.5 py-0.5 text-xs bg-[#1a1a25] rounded border border-[rgba(148,163,184,0.1)]">
                K
              </kbd>
            </div>
          </button>
          
          {/* Mobile Search */}
          <button 
            onClick={onSearchClick}
            className="md:hidden p-2 text-[#94a3b8] hover:text-white hover:bg-[#1a1a25] rounded-xl transition-all"
          >
            <Search className="w-5 h-5" />
          </button>
          
          {/* Notifications */}
          <button className="relative p-2 text-[#94a3b8] hover:text-white hover:bg-[#1a1a25] rounded-xl transition-all">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#22d3ee] rounded-full" />
          </button>
          
          {/* User */}
          <button className="flex items-center gap-2 p-1.5 hover:bg-[#1a1a25] rounded-xl transition-all">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#a855f7] to-[#22d3ee] flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}
