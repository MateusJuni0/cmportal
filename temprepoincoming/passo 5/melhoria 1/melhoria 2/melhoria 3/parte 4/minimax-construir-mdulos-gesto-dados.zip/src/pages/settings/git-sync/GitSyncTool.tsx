import React, { useState } from 'react';
import { 
  GitCommit, 
  GitBranch, 
  RotateCcw, 
  Check, 
  AlertCircle, 
  Clock,
  User,
  MessageSquare,
  ArrowRight,
  RefreshCw,
  Github,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';

interface Commit {
  id: string;
  hash: string;
  message: string;
  author: string;
  date: Date;
  branch: string;
}

const mockCommits: Commit[] = [
  { id: '1', hash: 'a1b2c3d', message: 'feat: add new landing page template', author: 'CMTecnologia', date: new Date(Date.now() - 1000 * 60 * 30), branch: 'main' },
  { id: '2', hash: 'e4f5g6h', message: 'fix: resolve mobile responsive issues', author: 'Developer', date: new Date(Date.now() - 1000 * 60 * 60 * 2), branch: 'main' },
  { id: '3', hash: 'i7j8k9l', message: 'feat: update color palette for dark mode', author: 'CMTecnologia', date: new Date(Date.now() - 1000 * 60 * 60 * 24), branch: 'develop' },
  { id: '4', hash: 'm0n1o2p', message: 'chore: update dependencies', author: 'CI/CD', date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), branch: 'main' },
  { id: '5', hash: 'q3r4s5t', message: 'feat: add new hero section variations', author: 'Developer', date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3), branch: 'feature/hero-sections' },
  { id: '6', hash: 'u6v7w8x', message: 'fix: resolve navigation menu z-index', author: 'CMTecnologia', date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4), branch: 'main' },
  { id: '7', hash: 'y9z0a1b', message: 'docs: update README with new features', author: 'Developer', date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5), branch: 'main' },
];

export function GitSyncTool() {
  const [commits] = useState<Commit[]>(mockCommits);
  const [selectedCommit, setSelectedCommit] = useState<string | null>(null);
  const [isReverting, setIsReverting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [revertSuccess, setRevertSuccess] = useState<string | null>(null);

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'agora mesmo';
    if (diffMins < 60) return `${diffMins}min atrás`;
    if (diffHours < 24) return `${diffHours}h atrás`;
    if (diffDays < 7) return `${diffDays}d atrás`;
    return date.toLocaleDateString('pt-BR');
  };

  const handleRevert = async (commitId: string) => {
    setIsReverting(true);
    setSelectedCommit(commitId);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsReverting(false);
    setRevertSuccess(commitId);
    setSelectedCommit(null);
    
    // Clear success message after 3 seconds
    setTimeout(() => setRevertSuccess(null), 3000);
  };

  const handleSync = async () => {
    setIsSyncing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSyncing(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <GitBranch className="w-7 h-7 text-[#f59e0b]" />
            Git Sync Tool
          </h1>
          <p className="text-[#94a3b8] mt-1">Histórico de commits e controle de versão</p>
        </div>
        
        <Button variant="default" onClick={handleSync} disabled={isSyncing}>
          {isSyncing ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Sincronizar
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Commit History */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GitCommit className="w-5 h-5 text-[#94a3b8]" />
                <span className="font-medium text-white">Histórico de Commits</span>
              </div>
              <Badge variant="default">{commits.length} commits</Badge>
            </div>
            
            <div className="divide-y divide-[rgba(148,163,184,0.1)]">
              {commits.map((commit, index) => (
                <motion.div
                  key={commit.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`p-4 hover:bg-[#1a1a25]/50 transition-colors ${
                    selectedCommit === commit.id ? 'bg-[#1a1a25]' : ''
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="w-8 h-8 rounded-full bg-[#f59e0b]/10 flex items-center justify-center flex-shrink-0">
                        <GitCommit className="w-4 h-4 text-[#f59e0b]" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <code className="text-sm text-cyan-400 font-mono">{commit.hash}</code>
                          <Badge variant={commit.branch === 'main' ? 'success' : 'default'}>
                            <GitBranch className="w-3 h-3 mr-1" />
                            {commit.branch}
                          </Badge>
                        </div>
                        <p className="text-sm text-white mt-1">{commit.message}</p>
                        <div className="flex items-center gap-4 mt-2 text-xs text-[#64748b]">
                          <span className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {commit.author}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatTimeAgo(commit.date)}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {revertSuccess === commit.id ? (
                        <Badge variant="success">
                          <Check className="w-3 h-3 mr-1" />
                          Revertido
                        </Badge>
                      ) : selectedCommit === commit.id && isReverting ? (
                        <div className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />
                          <span className="text-sm text-[#64748b]">Revertendo...</span>
                        </div>
                      ) : (
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleRevert(commit.id)}
                        >
                          <RotateCcw className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-4">
          <Card variant="glass">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-[#f59e0b]/10 flex items-center justify-center">
                  <Github className="w-5 h-5 text-[#f59e0b]" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Repositório</h4>
                  <p className="text-xs text-[#64748b]">cmtecnologia/site</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#94a3b8]">Branch atual</span>
                  <Badge variant="success">main</Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#94a3b8]">Última sincronização</span>
                  <span className="text-white">agora mesmo</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#94a3b8]">Commits hoje</span>
                  <span className="text-white">3</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h4 className="font-semibold text-white">Reverter Versão</h4>
            </div>
            <CardContent className="p-4">
              <p className="text-sm text-[#94a3b8] mb-4">
                Selecione um commit acima para reverter para aquela versão.
              </p>
              
              <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <p className="text-xs text-amber-200">
                  Esta ação irá criar um novo commit revertendo as mudanças.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h4 className="font-semibold text-white">Ações Rápidas</h4>
            </div>
            <CardContent className="p-4 space-y-2">
              <Button variant="default" className="w-full justify-start">
                <GitBranch className="w-4 h-4 mr-2" />
                Criar Branch
              </Button>
              <Button variant="default" className="w-full justify-start">
                <GitCommit className="w-4 h-4 mr-2" />
                Novo Commit
              </Button>
              <Button variant="default" className="w-full justify-start">
                <ArrowRight className="w-4 h-4 mr-2" />
                Merge Request
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
