import { useState } from 'react';
import { Bot, Plus, Settings, Users, X, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { Agent } from '@/types';

const skillOptions = [
  'Atendimento', 'Vendas', 'Suporte', 'Qualificação', 
  'Follow-up', 'Agendamento', 'Email', 'WhatsApp', 
  'TikTok', 'Instagram', 'LinkedIn', 'Análise'
];

const personalityOptions = [
  { value: 'friendly', label: 'Amigável e prestativo' },
  { value: 'professional', label: 'Profissional e objetivo' },
  { value: 'casual', label: 'Casual e descontraído' },
  { value: 'technical', label: 'Técnico e detalhista' },
];

export function AgentFactory() {
  const [agents, setAgents] = useState<Agent[]>([
    { id: '1', name: 'Sofia', role: 'Atendimento ao Cliente', personality: 'Amigável e prestativa', skills: ['Atendimento', 'Suporte', 'Agendamento'], status: 'online', createdAt: new Date() },
    { id: '2', name: 'Marco', role: 'Vendas', personality: 'Assertivo e persuasivo', skills: ['Vendas', 'Qualificação', 'Follow-up'], status: 'online', createdAt: new Date() },
    { id: '3', name: 'Ana', role: 'Nutrição de Leads', personality: 'Educada e paciente', skills: ['Email', 'WhatsApp', 'Follow-up'], status: 'training', createdAt: new Date() },
  ]);
  
  const [showModal, setShowModal] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [newAgent, setNewAgent] = useState({
    name: '',
    role: '',
    personality: '',
    skills: [] as string[],
  });

  const handleCreateAgent = async () => {
    if (!newAgent.name || !newAgent.role || !newAgent.personality) return;
    
    setIsCreating(true);
    
    const agent: Agent = {
      id: Date.now().toString(),
      name: newAgent.name,
      role: newAgent.role,
      personality: personalityOptions.find(p => p.value === newAgent.personality)?.label || '',
      skills: newAgent.skills,
      status: 'offline',
      createdAt: new Date(),
    };
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setAgents([...agents, agent]);
    setNewAgent({ name: '', role: '', personality: '', skills: [] });
    setShowModal(false);
    setIsCreating(false);
  };

  const toggleSkill = (skill: string) => {
    setNewAgent(prev => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill]
    }));
  };

  const statusColors = {
    online: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    offline: 'bg-gray-500/10 text-gray-400 border-gray-500/20',
    training: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Bot className="w-7 h-7 text-[#22d3ee]" />
            Agent Factory
          </h1>
          <p className="text-[#94a3b8] mt-1">Crie e gerencie agentes autônomos sem código</p>
        </div>
        
        <Button variant="primary" onClick={() => setShowModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Criar Agente
        </Button>
      </div>

      {/* Agent Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent, index) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="h-full hover:border-[#22d3ee]/30 transition-colors">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#22d3ee] to-[#a855f7] flex items-center justify-center">
                      <span className="text-white font-bold text-lg">{agent.name[0]}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{agent.name}</h3>
                      <p className="text-xs text-[#64748b]">{agent.role}</p>
                    </div>
                  </div>
                  <Badge className={statusColors[agent.status]}>
                    {agent.status === 'online' ? 'Online' : agent.status === 'training' ? 'Treinando' : 'Offline'}
                  </Badge>
                </div>
                
                <div className="mb-4">
                  <p className="text-xs text-[#64748b] mb-2">Personalidade</p>
                  <p className="text-sm text-white">{agent.personality}</p>
                </div>
                
                <div className="mb-4">
                  <p className="text-xs text-[#64748b] mb-2">Skills</p>
                  <div className="flex flex-wrap gap-1">
                    {agent.skills.map(skill => (
                      <span key={skill} className="px-2 py-1 text-xs bg-[#1a1a25] text-[#94a3b8] rounded-lg">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2 pt-2 border-t border-[rgba(148,163,184,0.1)]">
                  <Button variant="ghost" size="sm" className="flex-1">
                    <Settings className="w-4 h-4 mr-2" />
                    Gerenciar
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Create Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowModal(false)}
          />
          <div className="relative w-full max-w-lg bg-[#12121a] border border-[rgba(148,163,184,0.1)] rounded-2xl p-6 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-white">Criar Novo Agente</h2>
              <button 
                onClick={() => setShowModal(false)}
                className="p-1 text-[#94a3b8] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-4">
              <Input
                label="Nome do Agente"
                value={newAgent.name}
                onChange={(e) => setNewAgent({ ...newAgent, name: e.target.value })}
                placeholder="Ex: Sofia, Marco, Ana..."
              />
              
              <Input
                label="Função (O que ele faz)"
                value={newAgent.role}
                onChange={(e) => setNewAgent({ ...newAgent, role: e.target.value })}
                placeholder="Ex: Atendimento ao Cliente, Vendas..."
              />
              
              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-2">Personalidade</label>
                <select
                  value={newAgent.personality}
                  onChange={(e) => setNewAgent({ ...newAgent, personality: e.target.value })}
                  className="w-full bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#22d3ee] focus:ring-1 focus:ring-[#22d3ee]/30"
                >
                  <option value="">Selecione...</option>
                  {personalityOptions.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-2">Skills</label>
                <div className="flex flex-wrap gap-2">
                  {skillOptions.map(skill => (
                    <button
                      key={skill}
                      onClick={() => toggleSkill(skill)}
                      className={`px-3 py-1.5 text-sm rounded-lg transition-all ${
                        newAgent.skills.includes(skill)
                          ? 'bg-[#22d3ee]/20 text-[#22d3ee] border border-[#22d3ee]/30'
                          : 'bg-[#1a1a25] text-[#94a3b8] border border-[rgba(148,163,184,0.1)] hover:border-[#22d3ee]/30'
                      }`}
                    >
                      {skill}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="flex gap-3 pt-4">
                <Button variant="default" onClick={() => setShowModal(false)} className="flex-1">
                  Cancelar
                </Button>
                <Button 
                  variant="primary" 
                  onClick={handleCreateAgent} 
                  disabled={isCreating || !newAgent.name || !newAgent.role}
                  className="flex-1"
                >
                  {isCreating ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Plus className="w-4 h-4 mr-2" />
                  )}
                  Criar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
