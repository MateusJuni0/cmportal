import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Type, 
  Image as ImageIcon, 
  Layout,
  Eye,
  Save,
  Monitor,
  Smartphone,
  Tablet,
  Copy,
  GripVertical
} from 'lucide-react';
import { motion, Reorder } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';

interface LPComponent {
  id: string;
  type: 'hero' | 'text' | 'image' | 'button' | 'features' | 'cta' | 'footer';
  content: {
    title?: string;
    subtitle?: string;
    text?: string;
    imageUrl?: string;
    buttonText?: string;
    buttonUrl?: string;
    items?: { title: string; description: string }[];
  };
}

const componentTemplates: { type: LPComponent['type']; label: string; icon: React.ReactNode }[] = [
  { type: 'hero', label: 'Hero Section', icon: <Layout className="w-5 h-5" /> },
  { type: 'text', label: 'Texto', icon: <Type className="w-5 h-5" /> },
  { type: 'image', label: 'Imagem', icon: <ImageIcon className="w-5 h-5" /> },
  { type: 'button', label: 'Botão', icon: <Layout className="w-5 h-5" /> },
  { type: 'features', label: 'Features', icon: <Layout className="w-5 h-5" /> },
  { type: 'cta', label: 'CTA Section', icon: <Layout className="w-5 h-5" /> },
  { type: 'footer', label: 'Footer', icon: <Layout className="w-5 h-5" /> },
];

const defaultContent: Record<LPComponent['type'], LPComponent['content']> = {
  hero: {
    title: 'Título Principal',
    subtitle: 'Subtítulo da sua landing page',
    buttonText: 'Call to Action',
    buttonUrl: '#',
  },
  text: {
    title: 'Título do Texto',
    text: 'Seu texto aqui...',
  },
  image: {
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800',
    title: 'Legenda da imagem',
  },
  button: {
    buttonText: 'Clique aqui',
    buttonUrl: '#',
  },
  features: {
    title: 'Nossos Recursos',
    items: [
      { title: 'Recurso 1', description: 'Descrição do recurso 1' },
      { title: 'Recurso 2', description: 'Descrição do recurso 2' },
      { title: 'Recurso 3', description: 'Descrição do recurso 3' },
    ],
  },
  cta: {
    title: 'Pronto para começar?',
    subtitle: 'Entre em contato agora mesmo',
    buttonText: 'Fale Conosco',
  },
  footer: {
    text: '© 2024 Sua Empresa. Todos os direitos reservados.',
  },
};

type ViewMode = 'desktop' | 'tablet' | 'mobile';

export function LandingPageBuilder() {
  const [components, setComponents] = useState<LPComponent[]>([]);
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('desktop');
  const [showPreview, setShowPreview] = useState(false);

  const addComponent = (type: LPComponent['type']) => {
    const newComponent: LPComponent = {
      id: Date.now().toString(),
      type,
      content: { ...defaultContent[type] },
    };
    setComponents([...components, newComponent]);
    setSelectedComponent(newComponent.id);
  };

  const removeComponent = (id: string) => {
    setComponents(components.filter(c => c.id !== id));
    if (selectedComponent === id) {
      setSelectedComponent(null);
    }
  };

  const updateComponent = (id: string, content: Partial<LPComponent['content']>) => {
    setComponents(components.map(c => 
      c.id === id ? { ...c, content: { ...c.content, ...content } } : c
    ));
  };

  const handleReorder = (newOrder: LPComponent[]) => {
    setComponents(newOrder);
  };

  const duplicateComponent = (id: string) => {
    const component = components.find(c => c.id === id);
    if (component) {
      const newComponent: LPComponent = {
        ...component,
        id: Date.now().toString(),
        content: { ...component.content },
      };
      const index = components.findIndex(c => c.id === id);
      const newComponents = [...components];
      newComponents.splice(index + 1, 0, newComponent);
      setComponents(newComponents);
    }
  };

  const viewModeWidth = {
    desktop: 'w-full',
    tablet: 'w-[768px]',
    mobile: 'w-[375px]',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Layout className="w-7 h-7 text-[#a855f7]" />
            Landing Page Builder
          </h1>
          <p className="text-[#94a3b8] mt-1">Crie páginas de venda com templates prontos</p>
        </div>
        
        <div className="flex items-center gap-3">
          {/* View Mode Toggle */}
          <div className="flex items-center bg-[#12121a] rounded-xl p-1 border border-[rgba(148,163,184,0.1)]">
            <button
              onClick={() => setViewMode('desktop')}
              className={`p-2 rounded-lg transition-colors ${viewMode === 'desktop' ? 'bg-[#1a1a25] text-white' : 'text-[#64748b] hover:text-white'}`}
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('tablet')}
              className={`p-2 rounded-lg transition-colors ${viewMode === 'tablet' ? 'bg-[#1a1a25] text-white' : 'text-[#64748b] hover:text-white'}`}
            >
              <Tablet className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('mobile')}
              className={`p-2 rounded-lg transition-colors ${viewMode === 'mobile' ? 'bg-[#1a1a25] text-white' : 'text-[#64748b] hover:text-white'}`}
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>
          
          <Button variant="default" onClick={() => setShowPreview(!showPreview)}>
            <Eye className="w-4 h-4 mr-2" />
            Preview
          </Button>
          <Button variant="primary">
            <Save className="w-4 h-4 mr-2" />
            Salvar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Components Library */}
        <div className="space-y-4">
          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white">Componentes</h3>
            </div>
            <CardContent className="p-4 space-y-2">
              {componentTemplates.map((template) => (
                <button
                  key={template.type}
                  onClick={() => addComponent(template.type)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl bg-[#1a1a25]/50 hover:bg-[#1a1a25] text-[#94a3b8] hover:text-white transition-all"
                >
                  <div className="w-8 h-8 rounded-lg bg-[#a855f7]/10 flex items-center justify-center text-[#a855f7]">
                    {template.icon}
                  </div>
                  <span className="text-sm font-medium">{template.label}</span>
                  <Plus className="w-4 h-4 ml-auto" />
                </button>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Canvas / Preview */}
        <div className="lg:col-span-2">
          <div className="bg-[#0a0a0f] rounded-2xl border border-[rgba(148,163,184,0.1)] overflow-hidden">
            {/* Canvas Header */}
            <div className="p-3 border-b border-[rgba(148,163,184,0.1)] flex items-center justify-between">
              <span className="text-sm text-[#94a3b8]">Canvas</span>
              <Badge variant="default">{components.length} componentes</Badge>
            </div>
            
            {/* Canvas Content */}
            <div className="p-4 overflow-auto max-h-[70vh]">
              {components.length === 0 ? (
                <div className="text-center py-16">
                  <Layout className="w-12 h-12 text-[#64748b] mx-auto mb-4" />
                  <p className="text-[#94a3b8]">Arraste componentes da biblioteca</p>
                  <p className="text-sm text-[#64748b] mt-1">ou clique para adicionar</p>
                </div>
              ) : (
                <Reorder.Group 
                  axis="y" 
                  values={components} 
                  onReorder={handleReorder}
                  className="space-y-2"
                >
                  {components.map((component) => (
                    <Reorder.Item
                      key={component.id}
                      value={component}
                      className="bg-[#12121a] rounded-xl border border-[rgba(148,163,184,0.1)] overflow-hidden"
                    >
                      {/* Component Header */}
                      <div 
                        className={`flex items-center gap-2 p-3 cursor-pointer transition-colors ${
                          selectedComponent === component.id 
                            ? 'bg-[#a855f7]/10 border-l-2 border-l-[#a855f7]' 
                            : 'hover:bg-[#1a1a25]'
                        }`}
                        onClick={() => setSelectedComponent(component.id)}
                      >
                        <GripVertical className="w-4 h-4 text-[#64748b] cursor-grab" />
                        <span className="text-sm font-medium text-white flex-1">
                          {componentTemplates.find(t => t.type === component.type)?.label}
                        </span>
                        <button
                          onClick={(e) => { e.stopPropagation(); duplicateComponent(component.id); }}
                          className="p-1 text-[#64748b] hover:text-white"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); removeComponent(component.id); }}
                          className="p-1 text-[#64748b] hover:text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      
                      {/* Component Preview */}
                      <div className="p-4 border-t border-[rgba(148,163,184,0.1)]">
                        {component.type === 'hero' && (
                          <div className="text-center py-8 bg-gradient-to-br from-[#22d3ee]/10 to-[#a855f7]/10 rounded-xl">
                            <h2 className="text-2xl font-bold text-white">{component.content.title}</h2>
                            <p className="text-[#94a3b8] mt-2">{component.content.subtitle}</p>
                            <Button variant="primary" className="mt-4">{component.content.buttonText}</Button>
                          </div>
                        )}
                        {component.type === 'text' && (
                          <div>
                            <h3 className="text-lg font-semibold text-white">{component.content.title}</h3>
                            <p className="text-[#94a3b8] mt-2">{component.content.text}</p>
                          </div>
                        )}
                        {component.type === 'image' && (
                          <div className="rounded-xl overflow-hidden bg-[#1a1a25]">
                            <img src={component.content.imageUrl} alt="" className="w-full h-48 object-cover" />
                            {component.content.title && (
                              <p className="p-2 text-sm text-[#94a3b8] text-center">{component.content.title}</p>
                            )}
                          </div>
                        )}
                        {component.type === 'button' && (
                          <div className="text-center py-4">
                            <Button variant="primary">{component.content.buttonText}</Button>
                          </div>
                        )}
                        {component.type === 'features' && (
                          <div>
                            <h3 className="text-lg font-semibold text-white text-center mb-4">{component.content.title}</h3>
                            <div className="grid grid-cols-3 gap-4">
                              {component.content.items?.map((item, i) => (
                                <div key={i} className="text-center p-4 bg-[#1a1a25] rounded-xl">
                                  <h4 className="font-medium text-white">{item.title}</h4>
                                  <p className="text-sm text-[#94a3b8] mt-1">{item.description}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {component.type === 'cta' && (
                          <div className="text-center py-8 bg-gradient-to-r from-[#22d3ee]/20 to-[#a855f7]/20 rounded-xl">
                            <h2 className="text-xl font-bold text-white">{component.content.title}</h2>
                            <p className="text-[#94a3b8] mt-2">{component.content.subtitle}</p>
                            <Button variant="primary" className="mt-4">{component.content.buttonText}</Button>
                          </div>
                        )}
                        {component.type === 'footer' && (
                          <div className="text-center py-4 border-t border-[rgba(148,163,184,0.1)]">
                            <p className="text-sm text-[#64748b]">{component.content.text}</p>
                          </div>
                        )}
                      </div>
                    </Reorder.Item>
                  ))}
                </Reorder.Group>
              )}
            </div>
          </div>
        </div>

        {/* Properties Panel */}
        <div className="space-y-4">
          <Card>
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <h3 className="font-semibold text-white">Propriedades</h3>
            </div>
            <CardContent className="p-4">
              {selectedComponent ? (
                <div className="space-y-4">
                  {components.find(c => c.id === selectedComponent)?.type === 'hero' && (
                    <>
                      <div>
                        <label className="block text-sm text-[#94a3b8] mb-2">Título</label>
                        <input
                          type="text"
                          value={components.find(c => c.id === selectedComponent)?.content.title || ''}
                          onChange={(e) => updateComponent(selectedComponent, { title: e.target.value })}
                          className="w-full bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#a855f7]"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-[#94a3b8] mb-2">Subtítulo</label>
                        <input
                          type="text"
                          value={components.find(c => c.id === selectedComponent)?.content.subtitle || ''}
                          onChange={(e) => updateComponent(selectedComponent, { subtitle: e.target.value })}
                          className="w-full bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#a855f7]"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-[#94a3b8] mb-2">Texto do Botão</label>
                        <input
                          type="text"
                          value={components.find(c => c.id === selectedComponent)?.content.buttonText || ''}
                          onChange={(e) => updateComponent(selectedComponent, { buttonText: e.target.value })}
                          className="w-full bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#a855f7]"
                        />
                      </div>
                    </>
                  )}
                  {components.find(c => c.id === selectedComponent)?.type === 'text' && (
                    <>
                      <div>
                        <label className="block text-sm text-[#94a3b8] mb-2">Título</label>
                        <input
                          type="text"
                          value={components.find(c => c.id === selectedComponent)?.content.title || ''}
                          onChange={(e) => updateComponent(selectedComponent, { title: e.target.value })}
                          className="w-full bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#a855f7]"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-[#94a3b8] mb-2">Texto</label>
                        <textarea
                          value={components.find(c => c.id === selectedComponent)?.content.text || ''}
                          onChange={(e) => updateComponent(selectedComponent, { text: e.target.value })}
                          className="w-full h-24 bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-white resize-none focus:outline-none focus:border-[#a855f7]"
                        />
                      </div>
                    </>
                  )}
                  {components.find(c => c.id === selectedComponent)?.type === 'button' && (
                    <>
                      <div>
                        <label className="block text-sm text-[#94a3b8] mb-2">Texto do Botão</label>
                        <input
                          type="text"
                          value={components.find(c => c.id === selectedComponent)?.content.buttonText || ''}
                          onChange={(e) => updateComponent(selectedComponent, { buttonText: e.target.value })}
                          className="w-full bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#a855f7]"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-[#94a3b8] mb-2">URL</label>
                        <input
                          type="text"
                          value={components.find(c => c.id === selectedComponent)?.content.buttonUrl || ''}
                          onChange={(e) => updateComponent(selectedComponent, { buttonUrl: e.target.value })}
                          className="w-full bg-[#0a0a0f] border border-[rgba(148,163,184,0.1)] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#a855f7]"
                        />
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <p className="text-sm text-[#64748b] text-center py-4">
                  Selecione um componente para editar
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
