import { Lead, Client, FinancialData, WhatsAppAccount, Agent, LogEntry, TrainingDocument } from '@/types';

export const mockLeads: Lead[] = [
  { id: '1', name: 'João Silva', company: 'TechStart Brasil', email: 'joao@techstart.com', phone: '+5511999999999', score: 92, source: 'linkedin', status: 'new', createdAt: new Date('2024-01-15') },
  { id: '2', name: 'Maria Santos', company: 'Digital Solutions', email: 'maria@digitalsol.com', phone: '+5511888888888', score: 85, source: 'instagram', status: 'contacted', createdAt: new Date('2024-01-14') },
  { id: '3', name: 'Pedro Costa', company: 'Inovação Tech', email: 'pedro@inovacaotech.com', phone: '+5511777777777', score: 78, source: 'zaask', status: 'qualified', createdAt: new Date('2024-01-13') },
  { id: '4', name: 'Ana Oliveira', company: 'Cloud Systems', email: 'ana@cloudsystems.com', phone: '+5511666666666', score: 71, source: 'google', status: 'proposal', createdAt: new Date('2024-01-12') },
  { id: '5', name: 'Carlos Mendes', company: 'DataFlow', email: 'carlos@dataflow.com', phone: '+5511555555555', score: 65, source: 'linkedin', status: 'new', createdAt: new Date('2024-01-11') },
  { id: '6', name: 'Fernanda Lima', company: 'AI Masters', email: 'fernanda@aimasters.com', phone: '+5511444444444', score: 58, source: 'instagram', status: 'closed', createdAt: new Date('2024-01-10') },
  { id: '7', name: 'Ricardo Alves', company: 'WebForce', email: 'ricardo@webforce.com', phone: '+5511333333333', score: 52, source: 'zaask', status: 'contacted', createdAt: new Date('2024-01-09') },
  { id: '8', name: 'Juliana Ferreira', company: 'TechHub', email: 'juliana@techhub.com', phone: '+5511222222222', score: 45, source: 'direct', status: 'new', createdAt: new Date('2024-01-08') },
  { id: '9', name: 'Marcos Souza', company: 'DigitalHub', email: 'marcos@digitalhub.com', phone: '+5511111111111', score: 38, source: 'linkedin', status: 'qualified', createdAt: new Date('2024-01-07') },
  { id: '10', name: 'Patrícia Rodrigues', company: 'CloudPrime', email: 'patricia@cloudprime.com', phone: '+5511000000000', score: 25, source: 'instagram', status: 'new', createdAt: new Date('2024-01-06') },
];

export const mockClients: Client[] = [
  { id: '1', name: 'Empresa ABC Ltda', email: 'contato@abc.com', company: 'ABC Tecnologia', phone: '+5511999999999', status: 'active', plan: 'professional', startDate: new Date('2024-01-01'), monthlyValue: 1500 },
  { id: '2', name: 'XYZ Corporation', email: 'financeiro@xyz.com', company: 'XYZ Corp', phone: '+5511888888888', status: 'trial', plan: 'starter', startDate: new Date('2024-01-10'), trialEndDate: new Date('2024-01-24'), monthlyValue: 0 },
  { id: '3', name: 'Tech Innovators', email: 'ti@techinnovators.com', company: 'Tech Innovators SA', phone: '+5511777777777', status: 'active', plan: 'enterprise', startDate: new Date('2023-12-01'), monthlyValue: 5000 },
  { id: '4', name: 'StartUp Brasil', email: 'contato@startupbr.com', company: 'StartUp Brasil', phone: '+5511666666666', status: 'inactive', plan: 'starter', startDate: new Date('2023-11-15'), monthlyValue: 0 },
  { id: '5', name: 'Digital Commerce', email: 'admin@digitalcommerce.com', company: 'Digital Commerce', phone: '+5511555555555', status: 'active', plan: 'professional', startDate: new Date('2024-01-05'), monthlyValue: 1500 },
  { id: '6', name: 'Mega Corp', email: 'contato@megacorp.com', company: 'Mega Corp', phone: '+5511444444444', status: 'trial', plan: 'enterprise', startDate: new Date('2024-01-12'), trialEndDate: new Date('2024-01-26'), monthlyValue: 0 },
  { id: '7', name: 'Innovation Labs', email: 'hello@innovationlabs.com', company: 'Innovation Labs', phone: '+5511333333333', status: 'active', plan: 'professional', startDate: new Date('2023-12-20'), monthlyValue: 1500 },
  { id: '8', name: 'Future Tech', email: 'info@futuretech.com', company: 'Future Tech', phone: '+5511222222222', status: 'churned', plan: 'starter', startDate: new Date('2023-10-01'), monthlyValue: 0 },
];

export const mockFinancialData: FinancialData[] = [
  { date: 'Jan', revenue: 12500, costs: 3200, profit: 9300, apiCosts: 1200 },
  { date: 'Fev', revenue: 15200, costs: 3800, profit: 11400, apiCosts: 1500 },
  { date: 'Mar', revenue: 18900, costs: 4200, profit: 14700, apiCosts: 1800 },
  { date: 'Abr', revenue: 21300, costs: 5100, profit: 16200, apiCosts: 2200 },
  { date: 'Mai', revenue: 24800, costs: 5800, profit: 19000, apiCosts: 2600 },
  { date: 'Jun', revenue: 28400, costs: 6400, profit: 22000, apiCosts: 2900 },
  { date: 'Jul', revenue: 32100, costs: 7200, profit: 24900, apiCosts: 3300 },
  { date: 'Ago', revenue: 35800, costs: 8100, profit: 27700, apiCosts: 3700 },
  { date: 'Set', revenue: 39200, costs: 8800, profit: 30400, apiCosts: 4100 },
  { date: 'Out', revenue: 43500, costs: 9500, profit: 34000, apiCosts: 4500 },
  { date: 'Nov', revenue: 48200, costs: 10200, profit: 38000, apiCosts: 4900 },
  { date: 'Dez', revenue: 52000, costs: 11000, profit: 41000, apiCosts: 5300 },
];

export const mockWhatsAppAccounts: WhatsAppAccount[] = [
  { id: '1', phoneNumber: '+5511988887777', status: 'active', messagesSent: 1250, messagesReceived: 890, warmingProgress: 100, lastActivity: new Date() },
  { id: '2', phoneNumber: '+5511977776666', status: 'warming', messagesSent: 450, messagesReceived: 320, warmingProgress: 45, lastActivity: new Date(Date.now() - 3600000) },
  { id: '3', phoneNumber: '+5511966665555', status: 'warming', messagesSent: 280, messagesReceived: 190, warmingProgress: 28, lastActivity: new Date(Date.now() - 7200000) },
  { id: '4', phoneNumber: '+5511955554444', status: 'limited', messagesSent: 820, messagesReceived: 610, warmingProgress: 82, lastActivity: new Date(Date.now() - 10800000) },
  { id: '5', phoneNumber: '+5511944443333', status: 'active', messagesSent: 1580, messagesReceived: 1120, warmingProgress: 100, lastActivity: new Date(Date.now() - 1800000) },
];

export const mockAgents: Agent[] = [
  { id: '1', name: 'Sofia', role: 'Atendimento ao Cliente', personality: 'Amigável e prestativa', skills: ['Suporte', 'FAQ', 'Agendamento'], status: 'online', createdAt: new Date('2024-01-01') },
  { id: '2', name: 'Marco', role: 'Vendas', personality: 'Assertivo e persuasivo', skills: ['Qualificação', 'Follow-up', 'Fechamento'], status: 'online', createdAt: new Date('2024-01-05') },
  { id: '3', name: 'Ana', role: 'Nutrição de Leads', personality: 'Educada e paciente', skills: ['Email', 'WhatsApp', 'Content'], status: 'training', createdAt: new Date('2024-01-10') },
  { id: '4', name: 'Pedro', role: 'Suporte Técnico', personality: 'Técnico e detalhista', skills: ['Diagnóstico', 'Tickets', 'Escalação'], status: 'offline', createdAt: new Date('2024-01-12') },
  { id: '5', name: 'Lucia', role: 'Qualificação', personality: 'Curiosa e investigativa', skills: ['Qualificação', 'Pesquisa', 'Ranking'], status: 'online', createdAt: new Date('2024-01-15') },
];

export const mockLogEntries: LogEntry[] = [
  { id: '1', timestamp: new Date(Date.now() - 60000), level: 'info', message: 'Iniciando processo de qualificação do lead...', agentId: '2' },
  { id: '2', timestamp: new Date(Date.now() - 55000), level: 'info', message: 'Analisando perfil do lead: TechStart Brasil', agentId: '2' },
  { id: '3', timestamp: new Date(Date.now() - 50000), level: 'success', message: 'Lead qualificado com Score: 92/100', agentId: '2' },
  { id: '4', timestamp: new Date(Date.now() - 45000), level: 'info', message: 'Enviando email de apresentação...', agentId: '1' },
  { id: '5', timestamp: new Date(Date.now() - 40000), level: 'success', message: 'Email enviado com sucesso para joao@techstart.com', agentId: '1' },
  { id: '6', timestamp: new Date(Date.now() - 35000), level: 'info', message: 'Verificando disponibilidade de agenda...', agentId: '1' },
  { id: '7', timestamp: new Date(Date.now() - 30000), level: 'warning', message: 'Nenhum horário disponível para hoje', agentId: '1' },
  { id: '8', timestamp: new Date(Date.now() - 25000), level: 'info', message: 'Agendando para amanhã às 14:00', agentId: '1' },
  { id: '9', timestamp: new Date(Date.now() - 20000), level: 'success', message: 'Reunião agendada com sucesso', agentId: '1' },
  { id: '10', timestamp: new Date(Date.now() - 15000), level: 'info', message: 'Iniciando processo de follow-up...', agentId: '3' },
  { id: '11', timestamp: new Date(Date.now() - 10000), level: 'success', message: 'Follow-up enviado para 15 leads', agentId: '3' },
  { id: '12', timestamp: new Date(Date.now() - 5000), level: 'info', message: 'Aguardando resposta dos leads...', agentId: '3' },
];

export const mockTrainingDocuments: TrainingDocument[] = [
  { id: '1', name: 'Manual de Produtos 2024.pdf', type: 'pdf', status: 'completed', uploadedAt: new Date('2024-01-10'), processedAt: new Date('2024-01-10') },
  { id: '2', name: 'FAQ clientes.pdf', type: 'pdf', status: 'completed', uploadedAt: new Date('2024-01-12'), processedAt: new Date('2024-01-12') },
  { id: '3', name: 'Pricing Page', type: 'url', status: 'processing', uploadedAt: new Date('2024-01-15') },
  { id: '4', name: 'Case Studies.pdf', type: 'pdf', status: 'pending', uploadedAt: new Date('2024-01-16') },
];

export const warmingProgressData = [
  { day: 'Dia 1', sent: 10, received: 2, limit: 50 },
  { day: 'Dia 5', sent: 25, received: 8, limit: 50 },
  { day: 'Dia 10', sent: 45, received: 15, limit: 50 },
  { day: 'Dia 15', sent: 60, received: 22, limit: 100 },
  { day: 'Dia 20', sent: 85, received: 35, limit: 100 },
  { day: 'Dia 25', sent: 120, received: 48, limit: 150 },
  { day: 'Dia 30', sent: 150, received: 65, limit: 200 },
];
