import { create } from 'zustand';
import { TrainingDocument } from '@/types';

interface TrainingState {
  documents: TrainingDocument[];
  isProcessing: boolean;
  uploadDocument: (name: string, type: 'pdf' | 'url' | 'text', size?: number) => void;
  removeDocument: (id: string) => void;
  setProcessingStatus: (status: boolean) => void;
}

export const useTrainingStore = create<TrainingState>((set) => ({
  documents: [],
  isProcessing: false,
  uploadDocument: (name, type, size) => {
    const doc: TrainingDocument = {
      id: Date.now().toString(),
      name,
      type,
      size,
      status: 'processing',
      progress: 0,
      createdAt: new Date(),
    };
    set((state) => ({ documents: [doc, ...state.documents] }));

    // Simulate progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 20;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
      }
      set((state) => ({
        documents: state.documents.map((d) =>
          d.id === doc.id
            ? { ...d, progress: Math.round(progress), status: progress >= 100 ? 'completed' : 'processing' }
            : d
        ),
      }));
    }, 500);
  },
  removeDocument: (id) =>
    set((state) => ({
      documents: state.documents.filter((doc) => doc.id !== id),
    })),
  setProcessingStatus: (status) => set({ isProcessing: status }),
}));