import { create } from 'zustand';
import { GeneratedContent, TabValue } from '@/types';

interface CreativeState {
  activeTab: TabValue;
  generatedContent: GeneratedContent[];
  isGenerating: boolean;
  setActiveTab: (tab: TabValue) => void;
  generateContent: (type: TabValue, prompt: string) => void;
  clearGeneratedContent: () => void;
}

const mockImageResult =
  '🖼️ Imagem gerada com sucesso! [Visualização - Placeholder para Midjourney/DALL-E]';

const mockCopyResult =
  '✨ Assunto: Transforme seu potencial em resultados com a CMTecnologia\n\nOlá [Nome],\n\nVi que sua empresa está buscando inovar no setor de [Segmento]. Nossa solução AI-powered já ajudou mais de 500 empresas a aumentar suas conversões em 147%.\n\nQue tal agendarmos uma conversa de 15 minutos?\n\nAbraços,\n[Seu Nome]';

const mockVideoResult =
  '🎬 Vídeo de prospecção gerado! [Thumbnail placeholder - 30s de conteúdo dinâmico]';

export const useCreativeStore = create<CreativeState>((set) => ({
  activeTab: 'copy',
  generatedContent: [],
  isGenerating: false,
  setActiveTab: (tab) => set({ activeTab: tab }),
  generateContent: (type, prompt) => {
    set({ isGenerating: true });
    setTimeout(() => {
      const result =
        type === 'image'
          ? mockImageResult
          : type === 'video'
          ? mockVideoResult
          : mockCopyResult;
      const newContent: GeneratedContent = {
        id: Date.now().toString(),
        type,
        prompt,
        result,
        status: 'completed',
        createdAt: new Date(),
      };
      set((state) => ({
        generatedContent: [newContent, ...state.generatedContent],
        isGenerating: false,
      }));
    }, 2000);
  },
  clearGeneratedContent: () => set({ generatedContent: [] }),
}));