import { create } from 'zustand';
import { Agent } from '@/types';

interface AgentsState {
  agents: Agent[];
  selectedAgent: Agent | null;
  addAgent: (agent: Omit<Agent, 'id' | 'createdAt'>) => void;
  updateAgent: (id: string, updates: Partial<Agent>) => void;
  deleteAgent: (id: string) => void;
  selectAgent: (agent: Agent | null) => void;
  toggleAgentStatus: (id: string) => void;
}

const initialAgents: Agent[] = [
  {
    id: '1',
    name: 'Lead Qualifier Bot',
    function: 'Qualifica leads automaticamente usando IA',
    personality: 'Profissional e direto',
    skills: ['Classificação de Leads', 'Análise de Perfil', 'CRM Integration'],
    isOnline: true,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    name: 'Content Creator AI',
    function: 'Gera conteúdo para redes sociais e email marketing',
    personality: 'Criativo e engajador',
    skills: ['Copywriting', 'Design Prompting', 'SEO Optimization'],
    isOnline: true,
    createdAt: new Date('2024-01-20'),
  },
  {
    id: '3',
    name: 'WhatsApp Handler',
    function: 'Gerencia conversas no WhatsApp de forma autônoma',
    personality: 'Amigável e prestativo',
    skills: ['Natural Language', 'Context Management', 'Quick Responses'],
    isOnline: false,
    createdAt: new Date('2024-02-01'),
  },
];

export const useAgentsStore = create<AgentsState>((set) => ({
  agents: initialAgents,
  selectedAgent: null,
  addAgent: (agentData) =>
    set((state) => ({
      agents: [
        ...state.agents,
        {
          ...agentData,
          id: Date.now().toString(),
          createdAt: new Date(),
        },
      ],
    })),
  updateAgent: (id, updates) =>
    set((state) => ({
      agents: state.agents.map((agent) =>
        agent.id === id ? { ...agent, ...updates } : agent
      ),
    })),
  deleteAgent: (id) =>
    set((state) => ({
      agents: state.agents.filter((agent) => agent.id !== id),
    })),
  selectAgent: (agent) => set({ selectedAgent: agent }),
  toggleAgentStatus: (id) =>
    set((state) => ({
      agents: state.agents.map((agent) =>
        agent.id === id ? { ...agent, isOnline: !agent.isOnline } : agent
      ),
    })),
}));