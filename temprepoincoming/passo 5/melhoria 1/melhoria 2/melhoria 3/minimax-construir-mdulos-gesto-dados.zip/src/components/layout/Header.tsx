import React from 'react';
import { Menu, Bell, Search, User } from 'lucide-react';
import { Button } from '@/components/ui/Button';

interface HeaderProps {
  onMenuClick: () => void;
}

const pageTitles: Record<string, string> = {
  dashboard: 'Dashboard',
  leads: 'Leads Sniper',
  financial: 'Financial Command',
  clients: 'Client Management',
  whatsapp: 'WhatsApp Warming',
  'creative-lab': 'Multimodal Creative Lab',
  'agent-factory': 'Agent Factory',
  'ai-training': 'AI Training Ground',
  logs: 'Live Log Terminal',
};

export function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 h-16 bg-[#0a0a0f]/80 backdrop-blur-xl border-b border-[rgba(148,163,184,0.1)]">
      <div className="flex items-center justify-between h-full px-4 lg:px-6">
        {/* Left side */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onMenuClick}
            className="lg:hidden p-2 text-[#94a3b8] hover:text-white"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="hidden sm:block">
            <h1 className="text-lg font-semibold text-white">
              Sovereign Sales Engine
            </h1>
          </div>
        </div>
        
        {/* Right side */}
        <div className="flex items-center gap-3">
          {/* Search */}
          <div className="hidden md:flex items-center">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748b]" />
              <input
                type="text"
                placeholder="Buscar..."
                className="w-64 bg-[#12121a] border border-[rgba(148,163,184,0.1)] rounded-xl pl-10 pr-4 py-2 text-sm text-white placeholder-[#64748b] focus:outline-none focus:border-[#22d3ee] focus:ring-1 focus:ring-[#22d3ee]/30 transition-all"
              />
            </div>
          </div>
          
          {/* Notifications */}
          <button className="relative p-2 text-[#94a3b8] hover:text-white hover:bg-[#1a1a25] rounded-xl transition-all">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#22d3ee] rounded-full" />
          </button>
          
          {/* User */}
          <button className="flex items-center gap-2 p-1.5 hover:bg-[#1a1a25] rounded-xl transition-all">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#a855f7] to-[#22d3ee] flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}
