export interface Agent {
  id: string;
  name: string;
  function: string;
  personality: string;
  skills: string[];
  isOnline: boolean;
  createdAt: Date;
}

export interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'success' | 'warning' | 'error' | 'debug';
  agent?: string;
  message: string;
  data?: any;
}

export interface GeneratedContent {
  id: string;
  type: 'image' | 'copy' | 'video';
  prompt: string;
  result: string;
  status: 'generating' | 'completed' | 'error';
  createdAt: Date;
}

export interface TrainingDocument {
  id: string;
  name: string;
  type: 'pdf' | 'url' | 'text';
  size?: number;
  status: 'processing' | 'completed' | 'error';
  progress: number;
  createdAt: Date;
}

export type TabValue = 'image' | 'copy' | 'video';