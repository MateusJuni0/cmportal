import { create } from 'zustand';

export type AgentStatus = "online" | "offline";

export interface Agent {
  id: string;
  name: string;
  role: string;
  personality: string;
  status: AgentStatus;
  skills: string[];
}

export interface TrainingFile {
  id: string;
  name: string;
  size: string;
  type: "pdf" | "url";
}

/* ── Phase 4 Types ── */

export interface CMSSection {
  id: string;
  label: string;
  content: string;
  type: "text" | "heading" | "image";
  imageUrl?: string;
}

export interface LPComponent {
  id: string;
  type: "hero" | "features" | "testimonial" | "cta" | "text" | "image" | "pricing";
  label: string;
  props: Record<string, string>;
}

export interface GitCommit {
  id: string;
  hash: string;
  message: string;
  author: string;
  date: string;
  branch: string;
  filesChanged: number;
}

export type DeployStatus = "idle" | "building" | "deploying" | "success" | "error";

export interface Scene3DConfig {
  primaryColor: string;
  accentColor: string;
  lightIntensity: number;
  rotationSpeed: number;
  zoom: number;
  backgroundOpacity: number;
  particleDensity: number;
  glowIntensity: number;
}

export interface SpotlightResult {
  id: string;
  type: "lead" | "agent" | "file" | "page";
  title: string;
  subtitle: string;
}

interface AppState {
  /* ── Phase 3 ── */
  agents: Agent[];
  addAgent: (agent: Omit<Agent, "id">) => void;
  toggleAgentStatus: (id: string) => void;

  trainingFiles: TrainingFile[];
  addTrainingFile: (file: Omit<TrainingFile, "id">) => void;
  removeTrainingFile: (id: string) => void;
  clearTrainingFiles: () => void;

  /* ── Phase 4: CMS ── */
  cmsSections: CMSSection[];
  updateCMSSection: (id: string, content: string) => void;
  updateCMSImage: (id: string, imageUrl: string) => void;

  /* ── Phase 4: LP Builder ── */
  lpComponents: LPComponent[];
  addLPComponent: (comp: Omit<LPComponent, "id">) => void;
  removeLPComponent: (id: string) => void;
  reorderLPComponents: (components: LPComponent[]) => void;
  updateLPComponentProp: (id: string, key: string, value: string) => void;

  /* ── Phase 4: Git ── */
  commits: GitCommit[];

  /* ── Phase 4: Deploy ── */
  deployStatus: DeployStatus;
  setDeployStatus: (status: DeployStatus) => void;
  deployTarget: "vercel" | "vps";
  setDeployTarget: (target: "vercel" | "vps") => void;

  /* ── Phase 4: 3D ── */
  scene3D: Scene3DConfig;
  updateScene3D: (config: Partial<Scene3DConfig>) => void;

  /* ── Phase 4: Spotlight ── */
  isSpotlightOpen: boolean;
  setSpotlightOpen: (open: boolean) => void;
}

const INITIAL_AGENTS: Agent[] = [
  { id: "1", name: "Alpha", role: "SDR Focado em Tech", personality: "Persuasivo, Direto", status: "online", skills: ["Cold Email", "LinkedIn"] },
  { id: "2", name: "Bravo", role: "Nutrição de Leads", personality: "Empático, Educativo", status: "offline", skills: ["Follow-up", "CRM"] },
];

const INITIAL_CMS: CMSSection[] = [
  { id: "hero-title", label: "Hero — Título", content: "Transformamos empresas com tecnologia de ponta", type: "heading" },
  { id: "hero-subtitle", label: "Hero — Subtítulo", content: "Soluções inovadoras de IA e automação para impulsionar seus resultados", type: "text" },
  { id: "hero-image", label: "Hero — Imagem", content: "", type: "image", imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800" },
  { id: "about-title", label: "Sobre — Título", content: "Quem Somos", type: "heading" },
  { id: "about-text", label: "Sobre — Descrição", content: "Somos uma empresa de tecnologia focada em resultados. Combinamos inteligência artificial com estratégia de vendas para criar sistemas que vendem 24/7.", type: "text" },
  { id: "services-title", label: "Serviços — Título", content: "Nossos Serviços", type: "heading" },
  { id: "services-text", label: "Serviços — Descrição", content: "Desenvolvemos agentes de IA, landing pages de alta conversão e automações completas de vendas.", type: "text" },
];

const INITIAL_COMMITS: GitCommit[] = [
  { id: "1", hash: "a3f8c2d", message: "feat: adicionar novo hero section com animações", author: "Mateus", date: "2025-01-15T14:32:00Z", branch: "main", filesChanged: 5 },
  { id: "2", hash: "b7e1a9f", message: "fix: corrigir responsividade do menu mobile", author: "Mateus", date: "2025-01-14T11:20:00Z", branch: "main", filesChanged: 2 },
  { id: "3", hash: "c4d2b8e", message: "style: atualizar cores do design system", author: "Sistema IA", date: "2025-01-13T09:15:00Z", branch: "main", filesChanged: 8 },
  { id: "4", hash: "d9f3c7a", message: "feat: integrar formulário de contacto com webhook", author: "Mateus", date: "2025-01-12T16:45:00Z", branch: "main", filesChanged: 3 },
  { id: "5", hash: "e2a5d1b", message: "refactor: otimizar carregamento de imagens com lazy loading", author: "Sistema IA", date: "2025-01-11T10:30:00Z", branch: "main", filesChanged: 12 },
  { id: "6", hash: "f8c4e6d", message: "feat: adicionar seção de testemunhos", author: "Mateus", date: "2025-01-10T08:00:00Z", branch: "main", filesChanged: 4 },
  { id: "7", hash: "1b3d5f7", message: "chore: atualizar dependências e corrigir vulnerabilidades", author: "Sistema IA", date: "2025-01-09T13:20:00Z", branch: "main", filesChanged: 1 },
  { id: "8", hash: "2c4e6a8", message: "deploy: versão 2.1.0 — nova landing page de vendas", author: "Mateus", date: "2025-01-08T17:55:00Z", branch: "main", filesChanged: 15 },
];

const INITIAL_SCENE3D: Scene3DConfig = {
  primaryColor: "#00f3ff",
  accentColor: "#b537f2",
  lightIntensity: 0.75,
  rotationSpeed: 0.5,
  zoom: 1.0,
  backgroundOpacity: 0.8,
  particleDensity: 0.6,
  glowIntensity: 0.7,
};

export const useAppStore = create<AppState>((set) => ({
  /* ── Phase 3 ── */
  agents: INITIAL_AGENTS,
  addAgent: (agent) => set((state) => ({
    agents: [{ ...agent, id: Math.random().toString(36).substr(2, 9) }, ...state.agents]
  })),
  toggleAgentStatus: (id) => set((state) => ({
    agents: state.agents.map(a => a.id === id ? { ...a, status: a.status === 'online' ? 'offline' : 'online' } : a)
  })),

  trainingFiles: [],
  addTrainingFile: (file) => set((state) => ({
    trainingFiles: [...state.trainingFiles, { ...file, id: Math.random().toString(36).substr(2, 9) }]
  })),
  removeTrainingFile: (id) => set((state) => ({
    trainingFiles: state.trainingFiles.filter(f => f.id !== id)
  })),
  clearTrainingFiles: () => set({ trainingFiles: [] }),

  /* ── Phase 4: CMS ── */
  cmsSections: INITIAL_CMS,
  updateCMSSection: (id, content) => set((state) => ({
    cmsSections: state.cmsSections.map(s => s.id === id ? { ...s, content } : s)
  })),
  updateCMSImage: (id, imageUrl) => set((state) => ({
    cmsSections: state.cmsSections.map(s => s.id === id ? { ...s, imageUrl } : s)
  })),

  /* ── Phase 4: LP Builder ── */
  lpComponents: [],
  addLPComponent: (comp) => set((state) => ({
    lpComponents: [...state.lpComponents, { ...comp, id: Math.random().toString(36).substr(2, 9) }]
  })),
  removeLPComponent: (id) => set((state) => ({
    lpComponents: state.lpComponents.filter(c => c.id !== id)
  })),
  reorderLPComponents: (components) => set({ lpComponents: components }),
  updateLPComponentProp: (id, key, value) => set((state) => ({
    lpComponents: state.lpComponents.map(c => c.id === id ? { ...c, props: { ...c.props, [key]: value } } : c)
  })),

  /* ── Phase 4: Git ── */
  commits: INITIAL_COMMITS,

  /* ── Phase 4: Deploy ── */
  deployStatus: "idle",
  setDeployStatus: (status) => set({ deployStatus: status }),
  deployTarget: "vercel",
  setDeployTarget: (target) => set({ deployTarget: target }),

  /* ── Phase 4: 3D ── */
  scene3D: INITIAL_SCENE3D,
  updateScene3D: (config) => set((state) => ({
    scene3D: { ...state.scene3D, ...config }
  })),

  /* ── Phase 4: Spotlight ── */
  isSpotlightOpen: false,
  setSpotlightOpen: (open) => set({ isSpotlightOpen: open }),
}));
