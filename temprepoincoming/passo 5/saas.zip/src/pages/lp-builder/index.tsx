import { useState } from "react";
import { motion, AnimatePresence, Reorder } from "framer-motion";
import {
  LayoutTemplate, Plus, Trash2, GripVertical, Eye,
  Type, ImageIcon, MousePointerClick, Star, Zap,
  CreditCard, ChevronDown, ChevronUp, Sparkles,
  Monitor, Smartphone, Tablet,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { useAppStore, type LPComponent } from "@/store";

interface TemplateItem {
  type: LPComponent["type"];
  label: string;
  icon: typeof Type;
  description: string;
  defaultProps: Record<string, string>;
}

const TEMPLATES: TemplateItem[] = [
  {
    type: "hero", label: "Hero Section", icon: Zap, description: "Título principal com CTA",
    defaultProps: { title: "Transforme suas Vendas com IA", subtitle: "Automação inteligente para o seu negócio", cta: "Começar Agora" },
  },
  {
    type: "features", label: "Features Grid", icon: Star, description: "3 colunas de funcionalidades",
    defaultProps: { title: "Funcionalidades", f1: "Agentes Autónomos", f2: "Análise Preditiva", f3: "Automação Total" },
  },
  {
    type: "testimonial", label: "Depoimento", icon: Star, description: "Card de testemunho",
    defaultProps: { quote: "Esta solução triplicou nossas conversões em apenas 2 meses.", author: "João Silva", role: "CEO, TechCorp" },
  },
  {
    type: "cta", label: "Call to Action", icon: MousePointerClick, description: "Bloco de conversão",
    defaultProps: { title: "Pronto para crescer?", subtitle: "Agende uma demonstração gratuita", button: "Falar com Especialista" },
  },
  {
    type: "text", label: "Bloco de Texto", icon: Type, description: "Parágrafo livre",
    defaultProps: { content: "Adicione o texto do seu bloco aqui. Pode descrever um serviço, contar uma história ou detalhar a sua proposta de valor." },
  },
  {
    type: "image", label: "Imagem", icon: ImageIcon, description: "Imagem full-width",
    defaultProps: { url: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200", alt: "Dashboard Preview" },
  },
  {
    type: "pricing", label: "Preços", icon: CreditCard, description: "Tabela de planos",
    defaultProps: { title: "Planos", plan1: "Starter — €49/mês", plan2: "Pro — €149/mês", plan3: "Enterprise — Sob consulta" },
  },
];

function ComponentPreview({ comp }: { comp: LPComponent }) {
  switch (comp.type) {
    case "hero":
      return (
        <div className="text-center py-8 bg-gradient-to-b from-brand-50 to-white dark:from-brand-950/30 dark:to-zinc-900/50 rounded-xl">
          <h2 className="text-2xl font-bold mb-2">{comp.props.title}</h2>
          <p className="text-sm text-slate-500 dark:text-zinc-400 mb-4">{comp.props.subtitle}</p>
          <span className="inline-block px-5 py-2 bg-brand-600 dark:bg-[var(--color-neon-blue)] text-white text-sm font-medium rounded-xl">
            {comp.props.cta}
          </span>
        </div>
      );
    case "features":
      return (
        <div className="py-4">
          <h3 className="text-lg font-bold text-center mb-4">{comp.props.title}</h3>
          <div className="grid grid-cols-3 gap-3">
            {[comp.props.f1, comp.props.f2, comp.props.f3].map((f, i) => (
              <div key={i} className="bg-slate-50 dark:bg-zinc-800/50 rounded-xl p-3 text-center text-sm font-medium border border-slate-100 dark:border-white/5">
                {f}
              </div>
            ))}
          </div>
        </div>
      );
    case "testimonial":
      return (
        <div className="p-4 bg-slate-50 dark:bg-zinc-800/30 rounded-xl italic border border-slate-100 dark:border-white/5">
          <p className="text-sm mb-3">&quot;{comp.props.quote}&quot;</p>
          <p className="text-xs font-bold">{comp.props.author}</p>
          <p className="text-xs text-slate-400">{comp.props.role}</p>
        </div>
      );
    case "cta":
      return (
        <div className="text-center py-6 bg-gradient-to-r from-brand-500/10 to-purple-500/10 dark:from-[var(--color-neon-blue)]/10 dark:to-[var(--color-neon-purple)]/10 rounded-xl">
          <h3 className="text-lg font-bold mb-1">{comp.props.title}</h3>
          <p className="text-sm text-slate-500 dark:text-zinc-400 mb-4">{comp.props.subtitle}</p>
          <span className="inline-block px-4 py-2 bg-brand-600 dark:bg-white text-white dark:text-black text-sm font-medium rounded-xl">{comp.props.button}</span>
        </div>
      );
    case "text":
      return <p className="text-sm leading-relaxed text-slate-600 dark:text-zinc-400 py-2">{comp.props.content}</p>;
    case "image":
      return (
        <div className="rounded-xl overflow-hidden aspect-video">
          <img src={comp.props.url} alt={comp.props.alt} className="w-full h-full object-cover" />
        </div>
      );
    case "pricing":
      return (
        <div className="py-4">
          <h3 className="text-lg font-bold text-center mb-4">{comp.props.title}</h3>
          <div className="grid grid-cols-3 gap-3">
            {[comp.props.plan1, comp.props.plan2, comp.props.plan3].map((p, i) => (
              <div key={i} className={cn(
                "rounded-xl p-3 text-center text-xs font-medium border",
                i === 1 ? "bg-brand-50 dark:bg-brand-900/20 border-brand-200 dark:border-brand-700/50" : "bg-slate-50 dark:bg-zinc-800/50 border-slate-100 dark:border-white/5"
              )}>
                {p}
              </div>
            ))}
          </div>
        </div>
      );
    default:
      return null;
  }
}

export function LPBuilder() {
  const { lpComponents, addLPComponent, removeLPComponent, reorderLPComponents, updateLPComponentProp } = useAppStore();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"desktop" | "tablet" | "mobile">("desktop");

  const addComponent = (template: TemplateItem) => {
    addLPComponent({
      type: template.type,
      label: template.label,
      props: { ...template.defaultProps },
    });
  };

  return (
    <div className="max-w-7xl mx-auto h-full flex flex-col gap-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <LayoutTemplate className="w-8 h-8 text-brand-500 dark:text-[var(--color-neon-blue)]" />
            Landing Page Builder
          </h1>
          <p className="text-slate-500 dark:text-zinc-400">
            Construa páginas de venda de alta conversão arrastando componentes.
          </p>
        </div>
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-white/5 rounded-xl p-1 border border-slate-200 dark:border-white/10">
          {([
            { mode: "desktop" as const, icon: Monitor },
            { mode: "tablet" as const, icon: Tablet },
            { mode: "mobile" as const, icon: Smartphone },
          ]).map(({ mode, icon: Icon }) => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={cn(
                "p-2 rounded-lg transition-colors",
                viewMode === mode
                  ? "bg-white dark:bg-zinc-800 shadow-sm text-slate-900 dark:text-white"
                  : "text-slate-400 hover:text-slate-600 dark:text-zinc-500 dark:hover:text-zinc-300"
              )}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 overflow-hidden">
        {/* Components Library */}
        <div className="lg:col-span-3 glass-card p-4 overflow-y-auto">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500 px-2 mb-3">
            Componentes
          </p>
          <div className="space-y-2">
            {TEMPLATES.map((template) => {
              const Icon = template.icon;
              return (
                <button
                  key={template.type}
                  onClick={() => addComponent(template)}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left hover:bg-slate-50 dark:hover:bg-white/5 transition-colors border border-transparent hover:border-slate-200 dark:hover:border-white/10 group"
                >
                  <div className="p-2 bg-brand-50 dark:bg-zinc-800 rounded-lg text-brand-600 dark:text-[var(--color-neon-blue)] group-hover:scale-110 transition-transform">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{template.label}</p>
                    <p className="text-[11px] text-slate-400 dark:text-zinc-500 truncate">{template.description}</p>
                  </div>
                  <Plus className="w-4 h-4 text-slate-300 dark:text-zinc-600 group-hover:text-brand-500 dark:group-hover:text-[var(--color-neon-blue)] transition-colors shrink-0" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Canvas / Preview */}
        <div className="lg:col-span-5 glass-card p-4 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between mb-4 px-2">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500 flex items-center gap-2">
              <Eye className="w-3.5 h-3.5" />
              Canvas — {lpComponents.length} componentes
            </p>
            <span className="text-[10px] font-semibold px-2 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full tracking-wider uppercase">
              Live
            </span>
          </div>

          <div className={cn(
            "flex-1 overflow-y-auto bg-white dark:bg-zinc-900 rounded-2xl border border-slate-200 dark:border-white/5 mx-auto shadow-inner transition-all",
            viewMode === "desktop" && "w-full",
            viewMode === "tablet" && "max-w-md",
            viewMode === "mobile" && "max-w-xs"
          )}>
            <div className="p-4 space-y-3 min-h-full">
              {lpComponents.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center py-20 text-slate-400 dark:text-zinc-600">
                  <Sparkles className="w-12 h-12 opacity-20 mb-4" />
                  <p className="text-sm font-medium">Página em branco</p>
                  <p className="text-xs">Adicione componentes da barra lateral</p>
                </div>
              ) : (
                <Reorder.Group
                  axis="y"
                  values={lpComponents}
                  onReorder={reorderLPComponents}
                  className="space-y-3"
                >
                  {lpComponents.map((comp) => (
                    <Reorder.Item
                      key={comp.id}
                      value={comp}
                      className="cursor-grab active:cursor-grabbing"
                    >
                      <motion.div
                        layout
                        className={cn(
                          "relative group rounded-xl border transition-all",
                          editingId === comp.id
                            ? "border-brand-500 dark:border-[var(--color-neon-blue)] ring-2 ring-brand-500/20 dark:ring-[var(--color-neon-blue)]/20"
                            : "border-transparent hover:border-slate-200 dark:hover:border-white/10"
                        )}
                      >
                        {/* Component Actions Toolbar */}
                        <div className="absolute -top-3 right-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                          <button
                            onClick={() => setEditingId(editingId === comp.id ? null : comp.id)}
                            className="p-1 bg-white dark:bg-zinc-800 rounded-md text-slate-500 hover:text-brand-600 dark:text-zinc-400 dark:hover:text-[var(--color-neon-blue)] shadow-sm border border-slate-200 dark:border-white/10 transition-colors"
                          >
                            {editingId === comp.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                          </button>
                          <button
                            onClick={() => removeLPComponent(comp.id)}
                            className="p-1 bg-white dark:bg-zinc-800 rounded-md text-slate-500 hover:text-red-500 shadow-sm border border-slate-200 dark:border-white/10 transition-colors"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="flex items-start gap-2 p-2">
                          <div className="pt-1 opacity-0 group-hover:opacity-50 transition-opacity">
                            <GripVertical className="w-4 h-4 text-slate-400" />
                          </div>
                          <div className="flex-1">
                            <ComponentPreview comp={comp} />
                          </div>
                        </div>
                      </motion.div>
                    </Reorder.Item>
                  ))}
                </Reorder.Group>
              )}
            </div>
          </div>
        </div>

        {/* Properties Panel */}
        <div className="lg:col-span-4 glass-card p-4 overflow-y-auto">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500 px-2 mb-3">
            Propriedades
          </p>

          <AnimatePresence mode="wait">
            {editingId ? (
              <motion.div
                key={editingId}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                {(() => {
                  const comp = lpComponents.find(c => c.id === editingId);
                  if (!comp) return null;

                  return (
                    <>
                      <div className="flex items-center gap-2 px-2 pb-3 border-b border-slate-100 dark:border-white/5">
                        <span className="px-2 py-0.5 text-[10px] font-semibold uppercase rounded bg-brand-100 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300">{comp.type}</span>
                        <span className="text-sm font-medium">{comp.label}</span>
                      </div>
                      {Object.entries(comp.props).map(([key, value]) => (
                        <div key={key} className="space-y-1.5 px-2">
                          <label className="text-xs font-medium text-slate-500 dark:text-zinc-400 uppercase tracking-wider">{key}</label>
                          {value.length > 60 ? (
                            <textarea
                              value={value}
                              onChange={(e) => updateLPComponentProp(comp.id, key, e.target.value)}
                              rows={3}
                              className="w-full bg-slate-50 dark:bg-zinc-900/50 border border-slate-200 dark:border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 dark:focus:ring-[var(--color-neon-blue)] transition-all resize-none"
                            />
                          ) : (
                            <input
                              type="text"
                              value={value}
                              onChange={(e) => updateLPComponentProp(comp.id, key, e.target.value)}
                              className="w-full bg-slate-50 dark:bg-zinc-900/50 border border-slate-200 dark:border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 dark:focus:ring-[var(--color-neon-blue)] transition-all"
                            />
                          )}
                        </div>
                      ))}
                    </>
                  );
                })()}
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center py-20 text-slate-400 dark:text-zinc-600"
              >
                <MousePointerClick className="w-10 h-10 opacity-20 mb-3" />
                <p className="text-sm">Clique no ícone de expandir</p>
                <p className="text-xs">de um componente para editá-lo</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
