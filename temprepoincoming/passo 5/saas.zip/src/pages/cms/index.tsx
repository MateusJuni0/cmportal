import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileEdit, Save, Globe, Eye, EyeOff,
  Type, Heading, ImageIcon, Upload,
  Bold, Italic, AlignLeft, AlignCenter,
  Check, Loader2,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { useAppStore, type CMSSection } from "@/store";

export function CMSEditor() {
  const { cmsSections, updateCMSSection, updateCMSImage } = useAppStore();
  const [activeSection, setActiveSection] = useState<string>(cmsSections[0]?.id || "");
  const [showPreview, setShowPreview] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle");
  const [publishState, setPublishState] = useState<"idle" | "publishing" | "published">("idle");

  const active = cmsSections.find(s => s.id === activeSection);

  const handleSave = () => {
    setSaveState("saving");
    setTimeout(() => {
      setSaveState("saved");
      setTimeout(() => setSaveState("idle"), 2000);
    }, 1500);
  };

  const handlePublish = () => {
    setPublishState("publishing");
    setTimeout(() => {
      setPublishState("published");
      setTimeout(() => setPublishState("idle"), 2500);
    }, 2000);
  };

  const handleImageDrop = (e: React.DragEvent, sectionId: string) => {
    e.preventDefault();
    // Mock image upload
    updateCMSImage(sectionId, "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800");
  };

  const getTypeIcon = (type: CMSSection["type"]) => {
    switch (type) {
      case "heading": return Heading;
      case "text": return Type;
      case "image": return ImageIcon;
    }
  };

  return (
    <div className="max-w-7xl mx-auto h-full flex flex-col gap-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <FileEdit className="w-8 h-8 text-brand-500 dark:text-[var(--color-neon-blue)]" />
            Visual Site Editor
          </h1>
          <p className="text-slate-500 dark:text-zinc-400">
            Edite os textos e imagens do{" "}
            <span className="text-brand-600 dark:text-[var(--color-neon-blue)] font-medium">cmtecnologia.pt</span>{" "}
            diretamente aqui — sem abrir código.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors"
          >
            {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showPreview ? "Esconder" : "Preview"}
          </button>
          <button
            onClick={handleSave}
            disabled={saveState !== "idle"}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-slate-900 dark:bg-white text-white dark:text-black hover:bg-slate-800 dark:hover:bg-zinc-200 transition-colors disabled:opacity-70"
          >
            {saveState === "saving" ? <Loader2 className="w-4 h-4 animate-spin" /> :
             saveState === "saved" ? <Check className="w-4 h-4 text-green-500" /> :
             <Save className="w-4 h-4" />}
            {saveState === "saving" ? "Salvando..." : saveState === "saved" ? "Salvo!" : "Salvar"}
          </button>
          <button
            onClick={handlePublish}
            disabled={publishState !== "idle"}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-gradient-to-r from-brand-500 to-brand-700 dark:from-[var(--color-neon-blue)] dark:to-[var(--color-neon-purple)] text-white hover:opacity-90 transition-opacity disabled:opacity-70 shadow-lg shadow-brand-500/20 dark:shadow-[var(--color-neon-blue)]/20"
          >
            {publishState === "publishing" ? <Loader2 className="w-4 h-4 animate-spin" /> :
             publishState === "published" ? <Check className="w-4 h-4" /> :
             <Globe className="w-4 h-4" />}
            {publishState === "publishing" ? "Publicando..." : publishState === "published" ? "Publicado!" : "Publicar"}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0">
        {/* Section List */}
        <div className="lg:col-span-3 glass-card p-4 overflow-y-auto">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500 px-2 mb-3">
            Seções do Site
          </p>
          <div className="space-y-1.5">
            {cmsSections.map((section) => {
              const isActive = activeSection === section.id;
              const Icon = getTypeIcon(section.type);
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all text-left",
                    isActive
                      ? "bg-brand-50 dark:bg-white/5 text-brand-700 dark:text-white border border-brand-200 dark:border-white/10"
                      : "text-slate-600 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-white/5"
                  )}
                >
                  <Icon className={cn("w-4 h-4 shrink-0", isActive ? "text-brand-500 dark:text-[var(--color-neon-blue)]" : "")} />
                  <span className="truncate">{section.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Editor */}
        <div className="lg:col-span-5 glass-card p-6 flex flex-col">
          <AnimatePresence mode="wait">
            {active && (
              <motion.div
                key={active.id}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="flex flex-col flex-1"
              >
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-semibold text-lg">{active.label}</h2>
                  <span className={cn(
                    "px-2 py-1 text-[10px] font-semibold uppercase rounded-md tracking-wider",
                    active.type === "heading" && "bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400",
                    active.type === "text" && "bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400",
                    active.type === "image" && "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400"
                  )}>
                    {active.type}
                  </span>
                </div>

                {active.type !== "image" ? (
                  <>
                    {/* Toolbar */}
                    <div className="flex items-center gap-1 p-1 bg-slate-50 dark:bg-zinc-800/50 rounded-xl mb-4 border border-slate-100 dark:border-white/5">
                      {[Bold, Italic, AlignLeft, AlignCenter].map((Icon, i) => (
                        <button
                          key={i}
                          className="p-2 rounded-lg text-slate-500 dark:text-zinc-400 hover:bg-white dark:hover:bg-zinc-700 hover:text-slate-900 dark:hover:text-white transition-colors"
                        >
                          <Icon className="w-4 h-4" />
                        </button>
                      ))}
                    </div>

                    <textarea
                      value={active.content}
                      onChange={(e) => updateCMSSection(active.id, e.target.value)}
                      className={cn(
                        "flex-1 w-full bg-slate-50 dark:bg-zinc-900/50 border border-slate-200 dark:border-white/10 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-brand-500 dark:focus:ring-[var(--color-neon-blue)] transition-all resize-none shadow-inner",
                        active.type === "heading" ? "text-2xl font-bold" : "text-sm leading-relaxed"
                      )}
                    />
                  </>
                ) : (
                  <div className="flex-1 flex flex-col gap-4">
                    {/* Current Image */}
                    {active.imageUrl && (
                      <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-white/10 aspect-video">
                        <img src={active.imageUrl} alt="" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                        <p className="absolute bottom-3 left-3 text-xs text-white/70 font-mono">{active.label}</p>
                      </div>
                    )}

                    {/* Upload Area */}
                    <div
                      className="flex-1 min-h-[120px] border-2 border-dashed border-slate-300 dark:border-white/10 hover:border-brand-500 dark:hover:border-[var(--color-neon-blue)] rounded-2xl flex flex-col items-center justify-center gap-3 text-center cursor-pointer transition-colors group"
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => handleImageDrop(e, active.id)}
                    >
                      <div className="p-3 bg-slate-100 dark:bg-zinc-800 rounded-xl group-hover:scale-110 transition-transform">
                        <Upload className="w-6 h-6 text-slate-400 dark:text-zinc-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Arrastar nova imagem</p>
                        <p className="text-xs text-slate-400 dark:text-zinc-500">PNG, JPG ou WebP</p>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Live Preview */}
        <div className={cn("lg:col-span-4 glass-card p-6 flex flex-col transition-all", !showPreview && "hidden lg:flex")}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-lg flex items-center gap-2">
              <Eye className="w-5 h-5 text-slate-400" />
              Preview ao Vivo
            </h2>
            <span className="px-2 py-1 text-[10px] uppercase font-semibold bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-md tracking-wider">
              Tempo Real
            </span>
          </div>
          <div className="flex-1 bg-white dark:bg-zinc-900 rounded-2xl border border-slate-200 dark:border-white/5 overflow-y-auto shadow-inner">
            <div className="p-6 space-y-8">
              {/* Mock Website Preview */}
              <div className="border-b border-slate-100 dark:border-white/5 pb-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-yellow-400" />
                  <div className="w-3 h-3 rounded-full bg-green-400" />
                  <span className="ml-3 text-[10px] font-mono text-slate-400 bg-slate-50 dark:bg-zinc-800 px-3 py-0.5 rounded-full">cmtecnologia.pt</span>
                </div>
              </div>

              {cmsSections.map((section) => (
                <motion.div
                  key={section.id}
                  layout
                  className={cn(
                    "transition-all",
                    activeSection === section.id && "ring-2 ring-brand-500/30 dark:ring-[var(--color-neon-blue)]/30 rounded-xl p-3 -mx-3 bg-brand-50/30 dark:bg-[var(--color-neon-blue)]/5"
                  )}
                >
                  {section.type === "heading" && (
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">{section.content}</h3>
                  )}
                  {section.type === "text" && (
                    <p className="text-sm text-slate-600 dark:text-zinc-400 leading-relaxed">{section.content}</p>
                  )}
                  {section.type === "image" && section.imageUrl && (
                    <div className="rounded-xl overflow-hidden aspect-video">
                      <img src={section.imageUrl} alt="" className="w-full h-full object-cover" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
