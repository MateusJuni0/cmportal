import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  GitBranch, GitCommitHorizontal, RotateCcw, Check,
  User, Calendar, FileCode, Loader2, AlertTriangle,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { useAppStore, type GitCommit } from "@/store";

export function GitSync() {
  const { commits } = useAppStore();
  const [reverting, setReverting] = useState<string | null>(null);
  const [reverted, setReverted] = useState<string | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [confirmRevert, setConfirmRevert] = useState<string | null>(null);

  const handleRevert = (commitId: string) => {
    setReverting(commitId);
    setConfirmRevert(null);
    setTimeout(() => {
      setReverting(null);
      setReverted(commitId);
      setTimeout(() => setReverted(null), 3000);
    }, 2500);
  };

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 2000);
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString("pt-BR", {
      day: "2-digit", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit",
    });
  };

  const getCommitTypeColor = (message: string) => {
    if (message.startsWith("feat:")) return "text-green-500 dark:text-[var(--color-neon-green)]";
    if (message.startsWith("fix:")) return "text-amber-500";
    if (message.startsWith("style:")) return "text-purple-500 dark:text-[var(--color-neon-purple)]";
    if (message.startsWith("refactor:")) return "text-blue-500 dark:text-[var(--color-neon-blue)]";
    if (message.startsWith("deploy:")) return "text-pink-500 dark:text-[var(--color-neon-pink)]";
    if (message.startsWith("chore:")) return "text-slate-500";
    return "text-slate-600 dark:text-zinc-300";
  };

  const getCommitTypeTag = (message: string) => {
    const type = message.split(":")[0];
    const tagColors: Record<string, string> = {
      feat: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
      fix: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
      style: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
      refactor: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
      deploy: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400",
      chore: "bg-slate-100 text-slate-700 dark:bg-slate-800/50 dark:text-slate-400",
    };
    return { type, className: tagColors[type] || "bg-slate-100 text-slate-600 dark:bg-zinc-800 dark:text-zinc-400" };
  };

  return (
    <div className="max-w-5xl mx-auto h-full flex flex-col gap-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <GitBranch className="w-8 h-8 text-brand-500 dark:text-[var(--color-neon-blue)]" />
            Git Sync Tool
          </h1>
          <p className="text-slate-500 dark:text-zinc-400">
            Histórico de commits e controle de versão do site. Reverta alterações com um clique.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-white/5 rounded-xl border border-slate-200 dark:border-white/10 text-sm">
            <GitBranch className="w-4 h-4 text-green-500 dark:text-[var(--color-neon-green)]" />
            <span className="font-mono font-medium">main</span>
          </div>
          <button
            onClick={handleSync}
            disabled={syncing}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-slate-900 dark:bg-white text-white dark:text-black hover:bg-slate-800 dark:hover:bg-zinc-200 transition-colors disabled:opacity-70"
          >
            <RefreshCw className={cn("w-4 h-4", syncing && "animate-spin")} />
            {syncing ? "Sincronizando..." : "Sincronizar"}
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total Commits", value: commits.length.toString(), color: "text-brand-600 dark:text-[var(--color-neon-blue)]" },
          { label: "Último Deploy", value: "Há 2h", color: "text-green-600 dark:text-[var(--color-neon-green)]" },
          { label: "Branch Ativa", value: "main", color: "text-purple-600 dark:text-[var(--color-neon-purple)]" },
          { label: "Arquivos Alterados", value: "50", color: "text-amber-600 dark:text-amber-400" },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="glass-card p-4"
          >
            <p className="text-xs text-slate-400 dark:text-zinc-500 mb-1">{stat.label}</p>
            <p className={cn("text-xl font-bold font-mono", stat.color)}>{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Commit History */}
      <div className="flex-1 glass-card p-6 overflow-hidden flex flex-col">
        <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <GitCommitHorizontal className="w-5 h-5 text-slate-400" />
          Histórico de Commits
        </h2>

        <div className="flex-1 overflow-y-auto space-y-3 pr-2">
          {commits.map((commit: GitCommit, index: number) => {
            const tag = getCommitTypeTag(commit.message);
            const isReverting = reverting === commit.id;
            const isReverted = reverted === commit.id;

            return (
              <motion.div
                key={commit.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="relative group"
              >
                {/* Timeline line */}
                {index < commits.length - 1 && (
                  <div className="absolute left-[19px] top-[48px] bottom-[-12px] w-px bg-slate-200 dark:bg-white/5" />
                )}

                <div className={cn(
                  "flex gap-4 p-4 rounded-xl border transition-all",
                  isReverted
                    ? "bg-green-50 dark:bg-green-900/10 border-green-200 dark:border-green-800/30"
                    : "bg-white dark:bg-zinc-900/50 border-slate-100 dark:border-white/5 hover:border-slate-200 dark:hover:border-white/10"
                )}>
                  {/* Commit dot */}
                  <div className="shrink-0 mt-1">
                    <div className={cn(
                      "w-[10px] h-[10px] rounded-full border-2 border-white dark:border-zinc-900",
                      isReverted
                        ? "bg-green-500 shadow-[0_0_10px_var(--color-neon-green)]"
                        : index === 0 ? "bg-brand-500 dark:bg-[var(--color-neon-blue)]" : "bg-slate-300 dark:bg-zinc-600"
                    )} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <span className={cn("px-2 py-0.5 text-[10px] font-bold uppercase rounded tracking-wider", tag.className)}>
                        {tag.type}
                      </span>
                      <span className="font-mono text-xs text-slate-400 dark:text-zinc-500 bg-slate-50 dark:bg-zinc-800 px-2 py-0.5 rounded">
                        {commit.hash}
                      </span>
                    </div>

                    <p className={cn("text-sm font-medium mb-2", getCommitTypeColor(commit.message))}>
                      {commit.message.substring(commit.message.indexOf(":") + 2)}
                    </p>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 dark:text-zinc-500">
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {commit.author}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDate(commit.date)}
                      </span>
                      <span className="flex items-center gap-1">
                        <FileCode className="w-3 h-3" />
                        {commit.filesChanged} ficheiros
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="shrink-0 flex items-start">
                    <AnimatePresence mode="wait">
                      {confirmRevert === commit.id ? (
                        <motion.div
                          key="confirm"
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          className="flex items-center gap-2"
                        >
                          <span className="text-xs text-amber-500 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            Confirmar?
                          </span>
                          <button
                            onClick={() => handleRevert(commit.id)}
                            className="px-3 py-1.5 text-xs font-medium bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                          >
                            Sim
                          </button>
                          <button
                            onClick={() => setConfirmRevert(null)}
                            className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-white/10 rounded-lg hover:bg-slate-50 dark:hover:bg-white/5 transition-colors"
                          >
                            Não
                          </button>
                        </motion.div>
                      ) : isReverting ? (
                        <motion.div
                          key="reverting"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="flex items-center gap-2 text-brand-500 dark:text-[var(--color-neon-blue)]"
                        >
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span className="text-xs font-medium">Revertendo...</span>
                        </motion.div>
                      ) : isReverted ? (
                        <motion.div
                          key="reverted"
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="flex items-center gap-1.5 text-green-500 dark:text-[var(--color-neon-green)]"
                        >
                          <Check className="w-4 h-4" />
                          <span className="text-xs font-medium">Revertido!</span>
                        </motion.div>
                      ) : (
                        <motion.button
                          key="revert"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          onClick={() => setConfirmRevert(commit.id)}
                          className="opacity-0 group-hover:opacity-100 flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-white/10 rounded-lg hover:bg-slate-50 dark:hover:bg-white/5 text-slate-500 dark:text-zinc-400 transition-all"
                        >
                          <RotateCcw className="w-3 h-3" />
                          Reverter
                        </motion.button>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
