import { motion } from "framer-motion";
import { Box, RotateCw, Sun, Droplets, Sparkles, Eye } from "lucide-react";
import { cn } from "@/utils/cn";
import { useAppStore } from "@/store";

interface SliderProps {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (v: number) => void;
  icon: typeof Sun;
  unit?: string;
}

function ControlSlider({ label, value, min = 0, max = 1, step = 0.01, onChange, icon: Icon, unit = "%" }: SliderProps) {
  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-slate-400 dark:text-zinc-500" />
          <span className="text-sm font-medium">{label}</span>
        </div>
        <span className="text-xs font-mono text-slate-400 dark:text-zinc-500 bg-slate-100 dark:bg-zinc-800 px-2 py-0.5 rounded">
          {Math.round(value * 100)}{unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-2 bg-slate-200 dark:bg-zinc-800 rounded-full appearance-none cursor-pointer accent-brand-500 dark:accent-[var(--color-neon-blue)]
        [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-brand-500 dark:[&::-webkit-slider-thumb]:bg-[var(--color-neon-blue)] [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white dark:[&::-webkit-slider-thumb]:border-zinc-900"
      />
    </div>
  );
}

interface ColorPickerProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
}

function ColorPicker({ label, value, onChange }: ColorPickerProps) {
  const presets = ["#00f3ff", "#b537f2", "#00ff66", "#ff007f", "#ffd700", "#ff6b35", "#ffffff", "#3b82f6"];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">{label}</span>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400 dark:text-zinc-500 uppercase">{value}</span>
          <div className="w-6 h-6 rounded-lg border-2 border-white dark:border-zinc-700 shadow-sm" style={{ backgroundColor: value }} />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="flex gap-1.5 flex-wrap flex-1">
          {presets.map(color => (
            <button
              key={color}
              onClick={() => onChange(color)}
              className={cn(
                "w-7 h-7 rounded-lg border-2 transition-all hover:scale-110",
                value === color ? "border-white dark:border-zinc-300 ring-2 ring-brand-500 dark:ring-[var(--color-neon-blue)] scale-110" : "border-transparent"
              )}
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-7 h-7 rounded-lg cursor-pointer bg-transparent border-0 p-0"
        />
      </div>
    </div>
  );
}

export function ThreeDCustomizer() {
  const { scene3D, updateScene3D } = useAppStore();

  return (
    <div className="max-w-7xl mx-auto h-full flex flex-col gap-6 pb-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
          <Box className="w-8 h-8 text-brand-500 dark:text-[var(--color-neon-blue)]" />
          3D Scene Customizer
        </h1>
        <p className="text-slate-500 dark:text-zinc-400">
          Ajuste cores, iluminação e elementos da cena Spline do site usando sliders simples.
        </p>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0">
        {/* 3D Preview Area */}
        <div className="lg:col-span-8 glass-card p-6 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-lg flex items-center gap-2">
              <Eye className="w-5 h-5 text-slate-400" />
              Preview da Cena
            </h2>
            <span className="text-[10px] font-semibold px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full uppercase tracking-wider">
              Spline Runtime
            </span>
          </div>

          <div className="flex-1 bg-zinc-900 rounded-2xl border border-white/5 overflow-hidden relative min-h-[400px]">
            {/* Simulated 3D Scene */}
            <div className="absolute inset-0 flex items-center justify-center">
              {/* Background gradient */}
              <div
                className="absolute inset-0 transition-all duration-700"
                style={{
                  background: `radial-gradient(circle at 50% 50%, ${scene3D.primaryColor}15, transparent 70%)`,
                  opacity: scene3D.backgroundOpacity,
                }}
              />

              {/* Particles simulation */}
              <div className="absolute inset-0 overflow-hidden">
                {Array.from({ length: Math.floor(scene3D.particleDensity * 40) }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute rounded-full"
                    style={{
                      width: Math.random() * 4 + 1,
                      height: Math.random() * 4 + 1,
                      backgroundColor: i % 2 === 0 ? scene3D.primaryColor : scene3D.accentColor,
                      opacity: 0.3 + Math.random() * 0.4,
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                    }}
                    animate={{
                      y: [0, -30, 0],
                      opacity: [0.2, 0.6, 0.2],
                    }}
                    transition={{
                      duration: 3 + Math.random() * 4,
                      repeat: Infinity,
                      delay: Math.random() * 3,
                    }}
                  />
                ))}
              </div>

              {/* Main 3D Object Placeholder */}
              <motion.div
                className="relative z-10"
                animate={{
                  rotateY: [0, 360],
                }}
                transition={{
                  duration: 8 / (scene3D.rotationSpeed || 0.1),
                  repeat: Infinity,
                  ease: "linear",
                }}
                style={{ scale: scene3D.zoom }}
              >
                <div
                  className="w-40 h-40 rounded-3xl relative transition-all duration-500"
                  style={{
                    background: `linear-gradient(135deg, ${scene3D.primaryColor}40, ${scene3D.accentColor}40)`,
                    boxShadow: `0 0 ${scene3D.glowIntensity * 80}px ${scene3D.primaryColor}40, 0 0 ${scene3D.glowIntensity * 40}px ${scene3D.accentColor}40`,
                    border: `1px solid ${scene3D.primaryColor}30`,
                  }}
                >
                  <div
                    className="absolute inset-4 rounded-2xl transition-all duration-500"
                    style={{
                      background: `linear-gradient(45deg, ${scene3D.primaryColor}60, ${scene3D.accentColor}60)`,
                      boxShadow: `inset 0 0 30px ${scene3D.primaryColor}20`,
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Box
                      className="w-12 h-12 transition-all duration-500"
                      style={{ color: scene3D.primaryColor, filter: `drop-shadow(0 0 ${scene3D.glowIntensity * 20}px ${scene3D.primaryColor})` }}
                    />
                  </div>
                </div>
              </motion.div>

              {/* Light indicator */}
              <div
                className="absolute top-8 right-8 w-6 h-6 rounded-full transition-all duration-500"
                style={{
                  backgroundColor: "#ffd700",
                  opacity: scene3D.lightIntensity,
                  boxShadow: `0 0 ${scene3D.lightIntensity * 40}px #ffd700`,
                }}
              />
            </div>
          </div>
        </div>

        {/* Controls Panel */}
        <div className="lg:col-span-4 glass-card p-6 overflow-y-auto space-y-8">
          <div>
            <h2 className="font-semibold text-lg mb-1">Painel de Controle</h2>
            <p className="text-xs text-slate-400 dark:text-zinc-500">Ajustes em tempo real</p>
          </div>

          {/* Colors */}
          <div className="space-y-5">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Cores</p>
            <ColorPicker
              label="Cor Principal"
              value={scene3D.primaryColor}
              onChange={(v) => updateScene3D({ primaryColor: v })}
            />
            <ColorPicker
              label="Cor Secundária"
              value={scene3D.accentColor}
              onChange={(v) => updateScene3D({ accentColor: v })}
            />
          </div>

          <hr className="border-slate-200 dark:border-white/5" />

          {/* Lighting & Effects */}
          <div className="space-y-5">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Iluminação & Efeitos</p>
            <ControlSlider
              label="Intensidade da Luz"
              value={scene3D.lightIntensity}
              onChange={(v) => updateScene3D({ lightIntensity: v })}
              icon={Sun}
            />
            <ControlSlider
              label="Brilho/Glow"
              value={scene3D.glowIntensity}
              onChange={(v) => updateScene3D({ glowIntensity: v })}
              icon={Sparkles}
            />
            <ControlSlider
              label="Densidade de Partículas"
              value={scene3D.particleDensity}
              onChange={(v) => updateScene3D({ particleDensity: v })}
              icon={Droplets}
            />
          </div>

          <hr className="border-slate-200 dark:border-white/5" />

          {/* Transform */}
          <div className="space-y-5">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Transformações</p>
            <ControlSlider
              label="Velocidade de Rotação"
              value={scene3D.rotationSpeed}
              onChange={(v) => updateScene3D({ rotationSpeed: v })}
              icon={RotateCw}
            />
            <ControlSlider
              label="Zoom"
              value={scene3D.zoom}
              min={0.5}
              max={2}
              step={0.05}
              onChange={(v) => updateScene3D({ zoom: v })}
              icon={Eye}
              unit="x"
            />
            <ControlSlider
              label="Opacidade do Fundo"
              value={scene3D.backgroundOpacity}
              onChange={(v) => updateScene3D({ backgroundOpacity: v })}
              icon={Droplets}
            />
          </div>

          {/* Reset Button */}
          <button
            onClick={() => updateScene3D({
              primaryColor: "#00f3ff",
              accentColor: "#b537f2",
              lightIntensity: 0.75,
              rotationSpeed: 0.5,
              zoom: 1.0,
              backgroundOpacity: 0.8,
              particleDensity: 0.6,
              glowIntensity: 0.7,
            })}
            className="w-full py-2.5 rounded-xl text-sm font-medium border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors text-slate-600 dark:text-zinc-400"
          >
            Restaurar Padrões
          </button>
        </div>
      </div>
    </div>
  );
}
