import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Rocket, Cloud, Server, Check, X, Loader2,
  GitBranch, Clock, Globe, Activity, Shield,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { useAppStore } from "@/store";

interface DeployLog {
  id: string;
  message: string;
  status: "pending" | "running" | "done" | "error";
}

const DEPLOY_STEPS: Omit<DeployLog, "id" | "status">[] = [
  { message: "Verificando alterações no repositório..." },
  { message: "Instalando dependências (npm install)..." },
  { message: "Executando testes de integração..." },
  { message: "Compilando projeto (npm run build)..." },
  { message: "Otimizando assets e imagens..." },
  { message: "Enviando build para o servidor..." },
  { message: "Configurando SSL e DNS..." },
  { message: "Limpando cache CDN..." },
  { message: "Verificando health check..." },
  { message: "Deploy concluído com sucesso!" },
];

export function DeployPage() {
  const { deployStatus, setDeployStatus, deployTarget, setDeployTarget } = useAppStore();
  const [logs, setLogs] = useState<DeployLog[]>([]);
  const [progress, setProgress] = useState(0);

  const deployHistory = [
    { id: "1", date: "15 Jan 2025, 14:32", status: "success" as const, duration: "45s", branch: "main" },
    { id: "2", date: "14 Jan 2025, 11:20", status: "success" as const, duration: "38s", branch: "main" },
    { id: "3", date: "13 Jan 2025, 09:15", status: "error" as const, duration: "12s", branch: "feature/cms" },
    { id: "4", date: "12 Jan 2025, 16:45", status: "success" as const, duration: "52s", branch: "main" },
  ];

  const startDeploy = () => {
    setDeployStatus("building");
    setLogs([]);
    setProgress(0);

    let step = 0;
    const interval = setInterval(() => {
      if (step >= DEPLOY_STEPS.length) {
        clearInterval(interval);
        setDeployStatus("success");
        return;
      }

      const newLog: DeployLog = {
        id: step.toString(),
        message: DEPLOY_STEPS[step].message,
        status: step === DEPLOY_STEPS.length - 1 ? "done" : "running",
      };

      setLogs(prev => {
        const updated = prev.map(l => ({ ...l, status: "done" as const }));
        return [...updated, newLog];
      });

      setProgress(((step + 1) / DEPLOY_STEPS.length) * 100);

      if (step === 4) setDeployStatus("deploying");

      step++;
    }, 800);
  };

  // Reset after success
  useEffect(() => {
    if (deployStatus === "success") {
      const timeout = setTimeout(() => {
        // Keep success state visible
      }, 5000);
      return () => clearTimeout(timeout);
    }
  }, [deployStatus]);

  const isDeploying = deployStatus === "building" || deployStatus === "deploying";

  return (
    <div className="max-w-5xl mx-auto h-full flex flex-col gap-6 pb-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
          <Rocket className="w-8 h-8 text-brand-500 dark:text-[var(--color-neon-blue)]" />
          One-Click Deploy
        </h1>
        <p className="text-slate-500 dark:text-zinc-400">
          Suba o código alterado para produção com um único clique. Monitoramento em tempo real.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0">
        {/* Deploy Control */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Target Selector */}
          <div className="glass-card p-6 space-y-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">
              Destino do Deploy
            </p>

            <div className="grid grid-cols-2 gap-3">
              {([
                { id: "vercel" as const, label: "Vercel", icon: Cloud, desc: "Edge Network" },
                { id: "vps" as const, label: "VPS", icon: Server, desc: "Servidor Privado" },
              ]).map(({ id, label, icon: Icon, desc }) => (
                <button
                  key={id}
                  onClick={() => setDeployTarget(id)}
                  disabled={isDeploying}
                  className={cn(
                    "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all disabled:opacity-50",
                    deployTarget === id
                      ? "border-brand-500 dark:border-[var(--color-neon-blue)] bg-brand-50 dark:bg-[var(--color-neon-blue)]/5"
                      : "border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20"
                  )}
                >
                  <Icon className={cn(
                    "w-8 h-8",
                    deployTarget === id ? "text-brand-500 dark:text-[var(--color-neon-blue)]" : "text-slate-400 dark:text-zinc-500"
                  )} />
                  <span className="text-sm font-semibold">{label}</span>
                  <span className="text-[10px] text-slate-400 dark:text-zinc-500">{desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Deploy Info */}
          <div className="glass-card p-6 space-y-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">
              Informações do Deploy
            </p>
            {[
              { icon: GitBranch, label: "Branch", value: "main" },
              { icon: Globe, label: "Domínio", value: "cmtecnologia.pt" },
              { icon: Shield, label: "SSL", value: "Ativo" },
              { icon: Clock, label: "Último Deploy", value: "Há 2 horas" },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-white/5 last:border-0">
                <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-zinc-400">
                  <Icon className="w-4 h-4" />
                  {label}
                </div>
                <span className="text-sm font-medium font-mono">{value}</span>
              </div>
            ))}
          </div>

          {/* Deploy Button */}
          <motion.button
            onClick={startDeploy}
            disabled={isDeploying}
            whileTap={{ scale: 0.97 }}
            className={cn(
              "relative w-full group overflow-hidden rounded-2xl p-[2px] disabled:cursor-not-allowed transition-all",
              deployStatus === "success" ? "opacity-80" : ""
            )}
          >
            {/* Animated border gradient */}
            <div className={cn(
              "absolute inset-0 rounded-2xl transition-all duration-500",
              isDeploying
                ? "bg-gradient-to-r from-[var(--color-neon-blue)] via-[var(--color-neon-purple)] to-[var(--color-neon-blue)] animate-pulse"
                : deployStatus === "success"
                ? "bg-gradient-to-r from-[var(--color-neon-green)] to-green-500"
                : "bg-gradient-to-r from-brand-500 to-brand-700 dark:from-[var(--color-neon-blue)] dark:to-[var(--color-neon-purple)] group-hover:opacity-100 opacity-80"
            )} />

            <div className={cn(
              "relative rounded-[14px] px-6 py-4 flex items-center justify-center gap-3 transition-colors",
              deployStatus === "success"
                ? "bg-green-950"
                : "bg-zinc-900 dark:bg-zinc-950"
            )}>
              {isDeploying ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin text-[var(--color-neon-blue)]" />
                  <span className="text-lg font-bold text-white">
                    {deployStatus === "building" ? "Compilando..." : "Publicando..."}
                  </span>
                </>
              ) : deployStatus === "success" ? (
                <>
                  <Check className="w-6 h-6 text-[var(--color-neon-green)]" />
                  <span className="text-lg font-bold text-[var(--color-neon-green)]">Deploy Concluído!</span>
                </>
              ) : (
                <>
                  <Rocket className="w-6 h-6 text-white group-hover:animate-bounce" />
                  <span className="text-lg font-bold text-white">Fazer Deploy</span>
                </>
              )}
            </div>
          </motion.button>

          {/* Progress Bar */}
          <AnimatePresence>
            {(isDeploying || deployStatus === "success") && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="h-2 bg-slate-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                  <motion.div
                    className={cn(
                      "h-full rounded-full transition-colors",
                      deployStatus === "success"
                        ? "bg-[var(--color-neon-green)] shadow-[0_0_15px_var(--color-neon-green)]"
                        : "bg-[var(--color-neon-blue)] shadow-[0_0_15px_var(--color-neon-blue)]"
                    )}
                    style={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <p className="text-xs text-right mt-1 text-slate-400 dark:text-zinc-500 font-mono">{Math.round(progress)}%</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Side */}
        <div className="lg:col-span-7 flex flex-col gap-6 overflow-hidden">
          {/* Live Deploy Terminal */}
          <div className="glass-card p-4 flex-1 flex flex-col min-h-[250px] overflow-hidden">
            <div className="flex items-center justify-between mb-3 px-2">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-slate-400 dark:text-zinc-500" />
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Terminal de Deploy</span>
              </div>
              {isDeploying && (
                <span className="flex items-center gap-1.5 text-xs text-[var(--color-neon-blue)]">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[var(--color-neon-blue)] opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[var(--color-neon-blue)]" />
                  </span>
                  Em execução
                </span>
              )}
            </div>

            <div className="flex-1 bg-[#0d1117] rounded-xl p-4 overflow-y-auto font-mono text-xs space-y-1.5">
              {logs.length === 0 ? (
                <p className="text-slate-600">$ Aguardando comando de deploy...</p>
              ) : (
                logs.map((log) => (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-start gap-2"
                  >
                    {log.status === "done" ? (
                      <Check className="w-3.5 h-3.5 text-green-400 dark:text-[var(--color-neon-green)] shrink-0 mt-0.5" />
                    ) : log.status === "error" ? (
                      <X className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-[var(--color-neon-blue)] shrink-0 mt-0.5 animate-pulse" />
                    )}
                    <span className={cn(
                      log.status === "done" ? "text-green-400/80" :
                      log.status === "error" ? "text-red-400" :
                      "text-[var(--color-neon-blue)]"
                    )}>
                      {log.message}
                    </span>
                  </motion.div>
                ))
              )}
            </div>
          </div>

          {/* Deploy History */}
          <div className="glass-card p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500 px-2 mb-3">
              Histórico Recente
            </p>
            <div className="space-y-2">
              {deployHistory.map((deploy, i) => (
                <motion.div
                  key={deploy.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center justify-between p-3 bg-white dark:bg-zinc-900/50 rounded-xl border border-slate-100 dark:border-white/5"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      deploy.status === "success"
                        ? "bg-green-500 dark:bg-[var(--color-neon-green)] shadow-[0_0_8px_var(--color-neon-green)]"
                        : "bg-red-500"
                    )} />
                    <div>
                      <p className="text-sm font-medium">{deploy.date}</p>
                      <p className="text-xs text-slate-400 dark:text-zinc-500 font-mono">{deploy.branch}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-mono text-slate-400 dark:text-zinc-500">{deploy.duration}</span>
                    <span className={cn(
                      "px-2 py-0.5 text-[10px] font-bold uppercase rounded tracking-wider",
                      deploy.status === "success"
                        ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                        : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                    )}>
                      {deploy.status === "success" ? "Sucesso" : "Falhou"}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
