import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { CreativeLab } from "@/pages/creative-lab";
import { AgentFactory } from "@/pages/agents/factory";
import { AiTraining } from "@/pages/ai-training";
import { LiveLogTerminalPage } from "@/pages/agents/logs";
import { CMSEditor } from "@/pages/cms";
import { LPBuilder } from "@/pages/lp-builder";
import { ThreeDCustomizer } from "@/pages/settings/three-d-customizer";
import { GitSync } from "@/pages/settings/git-sync";
import { DeployPage } from "@/pages/settings/deploy";

export function App() {
  return (
    <BrowserRouter>
      <AppLayout>
        <Routes>
          <Route path="/" element={<Navigate to="/creative-lab" replace />} />
          {/* Phase 3 — IA & Criação */}
          <Route path="/creative-lab" element={<CreativeLab />} />
          <Route path="/agents/factory" element={<AgentFactory />} />
          <Route path="/agents/logs" element={<LiveLogTerminalPage />} />
          <Route path="/ai-training" element={<AiTraining />} />
          {/* Phase 4 — Site & Sistema */}
          <Route path="/cms" element={<CMSEditor />} />
          <Route path="/lp-builder" element={<LPBuilder />} />
          <Route path="/settings/3d-customizer" element={<ThreeDCustomizer />} />
          <Route path="/settings/git-sync" element={<GitSync />} />
          <Route path="/settings/deploy" element={<DeployPage />} />
        </Routes>
      </AppLayout>
    </BrowserRouter>
  );
}
