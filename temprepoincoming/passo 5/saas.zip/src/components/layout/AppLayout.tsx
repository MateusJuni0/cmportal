import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Brain, Sparkles, Bot, Terminal, Moon, Sun,
  FileEdit, LayoutTemplate, GitBranch, Rocket,
  Box, Search, Command, ChevronLeft, ChevronRight as ChevronRightIcon,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { motion } from "framer-motion";
import { SpotlightSearch } from "@/components/common/SpotlightSearch";
import { useAppStore } from "@/store";

interface NavSection {
  title: string;
  items: { name: string; path: string; icon: typeof Sparkles }[];
}

const navSections: NavSection[] = [
  {
    title: "IA & Criação",
    items: [
      { name: "Creative Lab", path: "/creative-lab", icon: Sparkles },
      { name: "Agent Factory", path: "/agents/factory", icon: Bot },
      { name: "Live Logs", path: "/agents/logs", icon: Terminal },
      { name: "AI Training", path: "/ai-training", icon: Brain },
    ],
  },
  {
    title: "Site & Sistema",
    items: [
      { name: "Site Editor", path: "/cms", icon: FileEdit },
      { name: "LP Builder", path: "/lp-builder", icon: LayoutTemplate },
      { name: "3D Customizer", path: "/settings/3d-customizer", icon: Box },
      { name: "Git Sync", path: "/settings/git-sync", icon: GitBranch },
      { name: "Deploy", path: "/settings/deploy", icon: Rocket },
    ],
  },
];

export function AppLayout({ children }: { children: ReactNode }) {
  const location = useLocation();
  const [isDark, setIsDark] = useState(true);
  const [collapsed, setCollapsed] = useState(false);
  const { setSpotlightOpen } = useAppStore();

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDark]);

  return (
    <div className="flex h-screen w-full bg-zinc-50 dark:bg-black text-slate-900 dark:text-zinc-50 overflow-hidden font-sans transition-colors duration-300">
      {/* Spotlight Global Search */}
      <SpotlightSearch />

      {/* Sidebar */}
      <aside
        className={cn(
          "border-r border-black/5 dark:border-white/10 bg-white/40 dark:bg-zinc-950/40 backdrop-blur-xl flex flex-col z-20 shadow-lg transition-all duration-300",
          collapsed ? "w-[72px]" : "w-64"
        )}
      >
        {/* Logo */}
        <div className={cn("p-4 flex items-center justify-between", collapsed ? "px-3" : "p-6")}>
          {!collapsed && (
            <div>
              <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-purple-600 dark:from-[var(--color-neon-blue)] dark:to-[var(--color-neon-purple)]">
                Sovereign Sales
              </h1>
              <p className="text-[10px] text-slate-500 dark:text-zinc-400 mt-0.5 uppercase tracking-[0.2em] font-semibold">
                Engine v4.0
              </p>
            </div>
          )}
          {collapsed && (
            <div className="w-full flex justify-center">
              <span className="text-lg font-black bg-clip-text text-transparent bg-gradient-to-r from-[var(--color-neon-blue)] to-[var(--color-neon-purple)]">
                SS
              </span>
            </div>
          )}
        </div>

        {/* Search Trigger */}
        <div className={cn("px-3 mb-2", collapsed && "px-2")}>
          <button
            onClick={() => setSpotlightOpen(true)}
            className={cn(
              "w-full flex items-center gap-2 text-sm text-slate-500 dark:text-zinc-400 hover:text-slate-700 dark:hover:text-zinc-200 bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 rounded-xl transition-colors",
              collapsed ? "p-2.5 justify-center" : "px-3 py-2"
            )}
          >
            <Search className="w-4 h-4 shrink-0" />
            {!collapsed && (
              <>
                <span className="flex-1 text-left">Buscar...</span>
                <kbd className="flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-medium bg-white dark:bg-zinc-800 rounded border border-slate-200 dark:border-zinc-700">
                  <Command className="w-2.5 h-2.5" />K
                </kbd>
              </>
            )}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden px-3 space-y-5 mt-2">
          {navSections.map((section) => (
            <div key={section.title}>
              {!collapsed && (
                <p className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-[0.15em] text-slate-400 dark:text-zinc-600">
                  {section.title}
                </p>
              )}
              <div className="space-y-1">
                {section.items.map((item) => {
                  const isActive =
                    location.pathname === item.path ||
                    (location.pathname === "/" && item.path === "/creative-lab");
                  const Icon = item.icon;

                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      title={item.name}
                      className={cn(
                        "flex items-center gap-3 rounded-xl text-sm font-medium transition-all relative overflow-hidden group",
                        collapsed ? "p-2.5 justify-center" : "px-3 py-2.5",
                        isActive
                          ? "text-brand-600 dark:text-white bg-white dark:bg-zinc-900/50 shadow-sm border border-black/5 dark:border-white/5"
                          : "text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-200 hover:bg-black/5 dark:hover:bg-white/5"
                      )}
                    >
                      {isActive && (
                        <motion.div
                          layoutId="active-nav"
                          className="absolute inset-0 bg-gradient-to-r from-brand-500/10 to-transparent dark:from-[var(--color-neon-blue)]/10 dark:to-transparent border-l-2 border-brand-500 dark:border-[var(--color-neon-blue)] z-0"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                        />
                      )}
                      <Icon
                        className={cn(
                          "w-5 h-5 relative z-10 shrink-0",
                          isActive ? "text-brand-500 dark:text-[var(--color-neon-blue)]" : ""
                        )}
                      />
                      {!collapsed && <span className="relative z-10 truncate">{item.name}</span>}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Bottom Controls */}
        <div className="p-3 border-t border-black/5 dark:border-white/10 space-y-1">
          <button
            onClick={() => setIsDark(!isDark)}
            className={cn(
              "flex items-center gap-2 w-full rounded-xl text-sm font-medium text-slate-600 dark:text-zinc-400 hover:bg-black/5 dark:hover:bg-white/5 transition-colors",
              collapsed ? "p-2.5 justify-center" : "px-3 py-2"
            )}
          >
            {isDark ? <Sun className="w-5 h-5 shrink-0" /> : <Moon className="w-5 h-5 shrink-0" />}
            {!collapsed && (isDark ? "Light Mode" : "Dark Mode Luxo")}
          </button>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={cn(
              "flex items-center gap-2 w-full rounded-xl text-sm font-medium text-slate-600 dark:text-zinc-400 hover:bg-black/5 dark:hover:bg-white/5 transition-colors",
              collapsed ? "p-2.5 justify-center" : "px-3 py-2"
            )}
          >
            {collapsed ? <ChevronRightIcon className="w-5 h-5 shrink-0" /> : <ChevronLeft className="w-5 h-5 shrink-0" />}
            {!collapsed && "Recolher"}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden bg-gradient-to-br from-slate-50 to-zinc-100 dark:from-zinc-950 dark:to-black">
        {/* Background glow effects */}
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-brand-500/20 dark:bg-[var(--color-neon-purple)]/10 blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-500/20 dark:bg-[var(--color-neon-blue)]/10 blur-[120px] pointer-events-none" />

        <div className="flex-1 overflow-y-auto overflow-x-hidden relative z-10 p-6 md:p-8">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="h-full"
          >
            {children}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
