import { useState, useEffect, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, User, Bot, FileText, Layout, ArrowRight, Command } from "lucide-react";
import { cn } from "@/utils/cn";
import { useAppStore, type SpotlightResult } from "@/store";
import { useNavigate } from "react-router-dom";

const MOCK_RESULTS: SpotlightResult[] = [
  // Leads
  { id: "l1", type: "lead", title: "João Silva", subtitle: "CEO — TechCorp • Score: 92" },
  { id: "l2", type: "lead", title: "Ana Martins", subtitle: "CTO — DataFlow • Score: 87" },
  { id: "l3", type: "lead", title: "Carlos Mendes", subtitle: "Diretor Vendas — SaaSPro • Score: 78" },
  { id: "l4", type: "lead", title: "Maria Oliveira", subtitle: "VP Marketing — GrowthLab • Score: 95" },
  // Agents
  { id: "a1", type: "agent", title: "Alpha", subtitle: "SDR Focado em Tech • Online" },
  { id: "a2", type: "agent", title: "Bravo", subtitle: "Nutrição de Leads • Offline" },
  { id: "a3", type: "agent", title: "Clara", subtitle: "Closer de Vendas • Online" },
  // Files
  { id: "f1", type: "file", title: "pitch-deck-q1-2025.pdf", subtitle: "Training Ground • 2.4 MB" },
  { id: "f2", type: "file", title: "proposta-comercial.docx", subtitle: "Training Ground • 1.1 MB" },
  { id: "f3", type: "file", title: "case-study-techcorp.pdf", subtitle: "Training Ground • 3.8 MB" },
  // Pages
  { id: "p1", type: "page", title: "Creative Lab", subtitle: "Gerar ativos de prospecção" },
  { id: "p2", type: "page", title: "Agent Factory", subtitle: "Criar e gerir agentes" },
  { id: "p3", type: "page", title: "Site Editor (CMS)", subtitle: "Editar conteúdo do site" },
  { id: "p4", type: "page", title: "Landing Page Builder", subtitle: "Construir landing pages" },
  { id: "p5", type: "page", title: "Git Sync", subtitle: "Histórico de versões" },
  { id: "p6", type: "page", title: "Deploy", subtitle: "Publicar alterações" },
];

const PAGE_ROUTES: Record<string, string> = {
  "Creative Lab": "/creative-lab",
  "Agent Factory": "/agents/factory",
  "Site Editor (CMS)": "/cms",
  "Landing Page Builder": "/lp-builder",
  "Git Sync": "/settings/git-sync",
  "Deploy": "/settings/deploy",
};

const typeIcons: Record<string, typeof User> = {
  lead: User,
  agent: Bot,
  file: FileText,
  page: Layout,
};

const typeLabels: Record<string, string> = {
  lead: "Leads",
  agent: "Agentes",
  file: "Arquivos",
  page: "Páginas",
};

export function SpotlightSearch() {
  const { isSpotlightOpen, setSpotlightOpen } = useAppStore();
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  // Keyboard shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSpotlightOpen(!isSpotlightOpen);
      }
      if (e.key === "Escape") {
        setSpotlightOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isSpotlightOpen, setSpotlightOpen]);

  // Focus input on open
  useEffect(() => {
    if (isSpotlightOpen) {
      setQuery("");
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isSpotlightOpen]);

  const filteredResults = useMemo(() => {
    if (!query.trim()) return MOCK_RESULTS.slice(0, 8);
    const q = query.toLowerCase();
    return MOCK_RESULTS.filter(
      r => r.title.toLowerCase().includes(q) || r.subtitle.toLowerCase().includes(q)
    );
  }, [query]);

  // Group by type
  const grouped = useMemo(() => {
    const groups: Record<string, SpotlightResult[]> = {};
    filteredResults.forEach(r => {
      if (!groups[r.type]) groups[r.type] = [];
      groups[r.type].push(r);
    });
    return groups;
  }, [filteredResults]);

  const flatResults = filteredResults;

  // Keyboard navigation
  useEffect(() => {
    const handleNav = (e: KeyboardEvent) => {
      if (!isSpotlightOpen) return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedIndex(i => Math.min(i + 1, flatResults.length - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedIndex(i => Math.max(i - 1, 0));
      } else if (e.key === "Enter" && flatResults[selectedIndex]) {
        e.preventDefault();
        handleSelect(flatResults[selectedIndex]);
      }
    };
    window.addEventListener("keydown", handleNav);
    return () => window.removeEventListener("keydown", handleNav);
  }, [isSpotlightOpen, flatResults, selectedIndex]);

  const handleSelect = (result: SpotlightResult) => {
    if (result.type === "page" && PAGE_ROUTES[result.title]) {
      navigate(PAGE_ROUTES[result.title]);
    }
    setSpotlightOpen(false);
  };

  return (
    <AnimatePresence>
      {isSpotlightOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={() => setSpotlightOpen(false)}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
            className="fixed top-[15%] left-1/2 -translate-x-1/2 w-full max-w-2xl z-50"
          >
            <div className="bg-white/90 dark:bg-zinc-900/95 backdrop-blur-2xl rounded-2xl border border-black/10 dark:border-white/10 shadow-2xl overflow-hidden">
              {/* Search Input */}
              <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-200/50 dark:border-white/5">
                <Search className="w-5 h-5 text-slate-400 dark:text-zinc-500 shrink-0" />
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => { setQuery(e.target.value); setSelectedIndex(0); }}
                  placeholder="Buscar leads, agentes, arquivos, páginas..."
                  className="flex-1 bg-transparent text-base outline-none placeholder:text-slate-400 dark:placeholder:text-zinc-600 text-slate-900 dark:text-white"
                />
                <kbd className="hidden sm:flex items-center gap-1 px-2 py-1 text-[10px] font-medium text-slate-400 dark:text-zinc-500 bg-slate-100 dark:bg-zinc-800 rounded-md border border-slate-200 dark:border-zinc-700">
                  ESC
                </kbd>
              </div>

              {/* Results */}
              <div className="max-h-[400px] overflow-y-auto py-2">
                {flatResults.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 dark:text-zinc-500">
                    <Search className="w-8 h-8 mx-auto mb-3 opacity-30" />
                    <p className="text-sm">Sem resultados para &quot;{query}&quot;</p>
                  </div>
                ) : (
                  Object.entries(grouped).map(([type, items]) => {
                    const Icon = typeIcons[type] || FileText;
                    return (
                      <div key={type} className="mb-1">
                        <div className="px-5 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">
                          {typeLabels[type] || type}
                        </div>
                        {items.map((result) => {
                          const globalIndex = flatResults.indexOf(result);
                          const isSelected = globalIndex === selectedIndex;
                          return (
                            <button
                              key={result.id}
                              onClick={() => handleSelect(result)}
                              onMouseEnter={() => setSelectedIndex(globalIndex)}
                              className={cn(
                                "w-full flex items-center gap-3 px-5 py-2.5 text-left transition-colors",
                                isSelected
                                  ? "bg-brand-50 dark:bg-white/5"
                                  : "hover:bg-slate-50 dark:hover:bg-white/5"
                              )}
                            >
                              <div className={cn(
                                "p-1.5 rounded-lg shrink-0",
                                type === "lead" && "bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400",
                                type === "agent" && "bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400",
                                type === "file" && "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400",
                                type === "page" && "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400"
                              )}>
                                <Icon className="w-4 h-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{result.title}</p>
                                <p className="text-xs text-slate-500 dark:text-zinc-400 truncate">{result.subtitle}</p>
                              </div>
                              {isSelected && (
                                <ArrowRight className="w-4 h-4 text-slate-400 dark:text-zinc-500 shrink-0" />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Footer */}
              <div className="px-5 py-2.5 border-t border-slate-200/50 dark:border-white/5 flex items-center justify-between text-[11px] text-slate-400 dark:text-zinc-500">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 bg-slate-100 dark:bg-zinc-800 rounded text-[10px] border border-slate-200 dark:border-zinc-700">↑↓</kbd> navegar</span>
                  <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 bg-slate-100 dark:bg-zinc-800 rounded text-[10px] border border-slate-200 dark:border-zinc-700">↵</kbd> selecionar</span>
                </div>
                <div className="flex items-center gap-1">
                  <Command className="w-3 h-3" />
                  <span>K para abrir</span>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
